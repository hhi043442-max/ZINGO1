# **App Name**: Zingo

## Core Features:

- Dynamic Double-UPI QR Generator: Sophisticated routing engine that generates QR codes for UPI ID 'sahnawaj.m@ptyes' for platform fees/onboarding, and 'sahnawaj.mondal@superyes' for core order transactions and COD settlements.
- Automated Multi-Wallet Ledger: Automated calculation of customer price (Base + ₹3 Margin + ₹5 Delivery) with real-time balance updates for Shopkeepers, Couriers, and Platform profit wallets stored in Firestore.
- 30-Day Paywall & Courier Activation: Subscription logic that automatically locks Shopkeeper dashboards every 30 days requiring renewal, and restricts Courier activation until a one-time ₹5 fee is processed via Firestore state management.
- AI Refund Integrity Tool: A diagnostic tool that uses reasoning to analyze return request reasons and live photos to flag high-probability fraudulent claims before Admin review.
- Courier COD Cap & Settlement System: Automated limit system that blocks couriers once COD collection hits ₹1000, unblocking them only upon payment to the core settlement UPI ID.
- Locked Five-Role Navigation: Hardened authentication flow with distinct, premium UI layouts for Super Admin, Staff, Shopkeeper, Courier, and Customer roles with mobile-first bottom navigation.
- Guest Engagement Guard: Auth-locked interactions that permit public product browsing but trigger high-conversion Tailwind modals when attempting to shop or access profile features without an account.

## Style Guidelines:

- A sophisticated dark mode palette inspired by tech-luxe visuals. Primary Color: Vibrant Indigo (#7a63ff); Background: Deep Charcoal Indigo (#0f0c19) with subtle HSL alignment; Accent: Deep Sky Blue (#6385ff).
- Primary and headline font: 'Poppins', a geometric sans-serif that ensures a precise and contemporary feel throughout all dashboard text.
- Mobile-first approach featuring glassmorphism elements, a sticky bottom navigation bar for quick access, and a retractable sidebar for the administrative desktop experience.
- Custom duo-tone line icons using Tailwind gradients for active states to highlight distinct merchant and courier tools.
- Uses 'animate-pulse' for critical system notifications (like refund alarms) and smooth slide-up transitions for the transaction QR code modals.