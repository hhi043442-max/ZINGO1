
'use client';

import React from 'react';
import { FirebaseProvider } from './provider';
import { app, auth, db } from './config';

export function FirebaseClientProvider({ children }: { children: React.ReactNode }) {
  return (
    <FirebaseProvider app={app} auth={auth} firestore={db}>
      {children}
    </FirebaseProvider>
  );
}
