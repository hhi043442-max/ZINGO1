
'use client';

import { initializeApp, getApps, type FirebaseApp } from 'firebase/app';
import { getAuth, type Auth } from 'firebase/auth';
import { getFirestore, type Firestore } from 'firebase/firestore';
import firebaseConfig from '../../firebase-applet-config.json';

let app: FirebaseApp;
let auth: Auth;
let db: Firestore;

try {
  if (getApps().length > 0) {
    app = getApps()[0];
  } else {
    app = initializeApp(firebaseConfig);
  }
  
  auth = getAuth(app);
  db = getFirestore(app, (firebaseConfig as any).firestoreDatabaseId || '(default)');
} catch (error) {
  console.error("Firebase Initialization Error:", error);
  // Fallback to avoid complete crash during build or invalid keys
  app = { name: 'DUMMY_APP' } as any;
  auth = { app: app, onAuthStateChanged: () => () => {}, signOut: async () => {} } as any;
  db = null as any;
}

export { app, auth, db };
