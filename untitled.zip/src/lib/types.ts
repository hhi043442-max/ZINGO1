
export type UserRole = 'SUPER_ADMIN' | 'STAFF' | 'SHOPKEEPER' | 'COURIER' | 'CUSTOMER';

export interface AppUser {
  uid: string;
  email: string;
  role: UserRole;
  displayName: string;
  walletBalance: number;
  isVerified: boolean;
  createdAt?: string;
  phone?: string;
  upiId?: string;
  activationUtr?: string; // UTR ID submitted during signup
  // Shopkeeper specific
  subscriptionExpiry?: string;
  isStoreOpen?: boolean;
  // Courier specific
  codCollected: number; // Current COD cash held by courier
  isBlocked?: boolean;
}

export interface Product {
  id: string;
  shopId: string;
  name: string;
  description: string;
  basePrice: number;
  imageUrl: string;
  category: string;
  sizes: string[];
  quantity: number;
  createdAt: any;
}

export interface Order {
  id: string;
  customerId: string;
  customerName: string;
  customerPhone: string;
  customerEmail: string;
  shopId: string;
  courierId?: string;
  items: Array<{
    productId: string;
    name: string;
    quantity: number;
    basePrice: number;
    selectedSize?: string;
  }>;
  totalAmount: number;
  status: OrderStatus;
  paymentMethod: 'COD' | 'ONLINE';
  paymentStatus: 'PENDING' | 'VERIFYING' | 'PAID';
  transactionId?: string;
  createdAt: any;
  deliveryAddress: string;
  qrData?: string;
  pickupAt?: any;
  deliveredAt?: any;
}

export interface PayoutRequest {
  id: string;
  userId: string;
  userName: string;
  userRole: UserRole;
  amount: number;
  upiId: string;
  status: 'PENDING' | 'PAID' | 'REJECTED';
  createdAt: any;
}

export interface DebtSettlement {
  id: string;
  userId: string;
  userName: string;
  amount: number;
  transactionId: string;
  status: 'PENDING' | 'VERIFIED' | 'REJECTED';
  createdAt: any;
}

export type OrderStatus = 
  | 'PENDING_SHOP_APPROVAL' 
  | 'READY_FOR_PICKUP' 
  | 'ACCEPTED_BY_COURIER'
  | 'PICKED_UP' 
  | 'DELIVERED' 
  | 'RETURN_INITIATED' 
  | 'RETURNED' 
  | 'REFUNDED' 
  | 'CANCELLED';

export const PLATFORM_FEE = 3;
export const DELIVERY_FEE = 15;
export const COURIER_EARNING_PER_ORDER = 5;
export const COURIER_COD_LIMIT = 1000;
export const COURIER_MIN_WITHDRAW = 300;
export const SHOPKEEPER_MIN_WITHDRAW = 1500;
export const UPI_ID_ADMIN = 'sahnawaj.m@ptyes';
