'use server';
/**
 * @fileOverview An AI-powered tool for detecting potential fraud in customer return requests.
 *
 * - adminRefundFraudDetection - A function that analyzes customer return reasons and photos for fraud.
 * - AdminRefundFraudDetectionInput - The input type for the adminRefundFraudDetection function.
 * - AdminRefundFraudDetectionOutput - The return type for the adminRefundFraudDetection function.
 */

import { ai } from '@/ai/genkit';
import { z } from 'genkit';

const AdminRefundFraudDetectionInputSchema = z.object({
  returnReason: z.string().describe('The customer\u0027s stated reason for the return.'),
  livePhotoDataUri: z
    .string()
    .describe(
      "A live photo of the returned item, as a data URI that must include a MIME type and use Base64 encoding. Expected format: 'data:<mimetype>;base64,<encoded_data>'."
    ),
});
export type AdminRefundFraudDetectionInput = z.infer<typeof AdminRefundFraudDetectionInputSchema>;

const AdminRefundFraudDetectionOutputSchema = z.object({
  fraudLikelihoodScore: z
    .number()
    .min(0)
    .max(1)
    .describe('A score indicating the likelihood of fraud (0 = no fraud, 1 = high fraud likelihood).'),
  fraudFlag: z.boolean().describe('True if the request is flagged as potentially fraudulent, false otherwise.'),
  reasoning: z.string().describe('The AI\u0027s reasoning for the fraud likelihood score and flag.'),
});
export type AdminRefundFraudDetectionOutput = z.infer<typeof AdminRefundFraudDetectionOutputSchema>;

export async function adminRefundFraudDetection(
  input: AdminRefundFraudDetectionInput
): Promise<AdminRefundFraudDetectionOutput> {
  return adminRefundFraudDetectionFlow(input);
}

const prompt = ai.definePrompt({
  name: 'adminRefundFraudDetectionPrompt',
  input: { schema: AdminRefundFraudDetectionInputSchema },
  output: { schema: AdminRefundFraudDetectionOutputSchema },
  prompt: `You are an expert fraud detection agent specializing in e-commerce return claims.
Your task is to analyze customer return requests based on their stated reason and a live photo of the item.
Assess the likelihood of fraudulent activity and provide a score, a flag, and your reasoning.

Return Reason: {{{returnReason}}}
Live Photo: {{media url=livePhotoDataUri}}

Based on this information, provide:
- A fraud likelihood score (0.0 to 1.0, where 1.0 is highly fraudulent).
- A boolean flag (true if likely fraudulent, false otherwise).
- A detailed reasoning for your assessment.

Consider inconsistencies between the reason and the photo, common fraud patterns, and the condition of the item in the photo.
`,
});

const adminRefundFraudDetectionFlow = ai.defineFlow(
  {
    name: 'adminRefundFraudDetectionFlow',
    inputSchema: AdminRefundFraudDetectionInputSchema,
    outputSchema: AdminRefundFraudDetectionOutputSchema,
  },
  async (input) => {
    const { output } = await prompt(input);
    return output!;
  }
);
