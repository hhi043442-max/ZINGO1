import { config } from 'dotenv';
config();

import '@/ai/flows/admin-refund-fraud-detection.ts';