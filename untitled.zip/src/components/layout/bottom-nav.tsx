"use client"

import React from 'react';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { Home, ShoppingBag, Truck, User, LayoutDashboard, Settings } from 'lucide-react';
import { cn } from '@/lib/utils';
import { UserRole } from '@/lib/types';

interface BottomNavProps {
  role: UserRole;
}

export function BottomNav({ role }: BottomNavProps) {
  const pathname = usePathname();

  const getNavItems = () => {
    switch (role) {
      case 'CUSTOMER':
        return [
          { icon: Home, label: 'Home', href: '/customer/home' },
          { icon: ShoppingBag, label: 'Orders', href: '/customer/orders' },
          { icon: User, label: 'Profile', href: '/customer/profile' },
        ];
      case 'SHOPKEEPER':
        return [
          { icon: LayoutDashboard, label: 'Stats', href: '/shopkeeper/dashboard' },
          { icon: ShoppingBag, label: 'Products', href: '/shopkeeper/products' },
          { icon: User, label: 'Wallet', href: '/shopkeeper/wallet' },
        ];
      case 'COURIER':
        return [
          { icon: LayoutDashboard, label: 'Tasks', href: '/courier/dashboard' },
          { icon: Truck, label: 'Deliver', href: '/courier/active' },
          { icon: User, label: 'Earnings', href: '/courier/wallet' },
        ];
      default:
        return [
          { icon: LayoutDashboard, label: 'Admin', href: `/${role.toLowerCase()}/dashboard` },
          { icon: Settings, label: 'Manage', href: `/${role.toLowerCase()}/manage` },
        ];
    }
  };

  return (
    <nav className="bottom-nav">
      {getNavItems().map((item) => (
        <Link 
          key={item.href} 
          href={item.href}
          className={cn(
            "flex flex-col items-center justify-center gap-1 transition-all duration-300",
            pathname === item.href ? "text-primary scale-110" : "text-muted-foreground hover:text-foreground"
          )}
        >
          <item.icon className="w-6 h-6" />
          <span className="text-[10px] font-medium">{item.label}</span>
        </Link>
      ))}
    </nav>
  );
}