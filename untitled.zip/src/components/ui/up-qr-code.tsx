"use client"

import React from 'react';
import { Card } from './card';

interface UPIQRCodeProps {
  upiId: string;
  amount?: number;
  payeeName?: string;
  transactionNote?: string;
  className?: string;
}

export function UPIQRCode({ upiId, amount, payeeName = "Zingo Platform", transactionNote = "Transaction", className }: UPIQRCodeProps) {
  // Construct UPI URL: upi://pay?pa=upiid&pn=name&am=amount&tn=note&cu=INR
  const upiUrl = `upi://pay?pa=${upiId}&pn=${encodeURIComponent(payeeName)}${amount ? `&am=${amount}` : ''}&tn=${encodeURIComponent(transactionNote)}&cu=INR`;
  
  // Use QR Server API for dynamic generation
  const qrImageUrl = `https://api.qrserver.com/v1/create-qr-code/?size=250x250&data=${encodeURIComponent(upiUrl)}`;

  return (
    <Card className={`p-6 flex flex-col items-center gap-4 bg-white text-black rounded-3xl ${className}`}>
      <div className="text-center">
        <p className="text-xs font-semibold text-muted-foreground uppercase tracking-widest mb-1">Scan to Pay</p>
        <p className="text-lg font-bold truncate max-w-[200px]">{upiId}</p>
      </div>
      
      <div className="relative group p-2 bg-white rounded-2xl">
        <img 
          src={qrImageUrl} 
          alt="UPI QR Code" 
          className="w-48 h-48 sm:w-56 sm:h-56 transition-transform duration-500 group-hover:scale-105"
        />
      </div>

      {amount && (
        <div className="text-2xl font-black text-primary">
          ₹{amount.toFixed(2)}
        </div>
      )}
      
      <div className="text-[10px] text-muted-foreground font-medium uppercase text-center">
        Payment secured by Zingo Double-Routing Engine
      </div>
    </Card>
  );
}