
"use client"

import React, { useState } from 'react';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardHeader, CardContent, CardFooter } from "@/components/ui/card";
import { Store, Truck, ShoppingBag, ArrowLeft, Loader2, PartyPopper } from 'lucide-react';
import Link from 'next/link';
import { UserRole, UPI_ID_ADMIN } from '@/lib/types';
import { useRouter } from 'next/navigation';
import { UPIQRCode } from '@/components/ui/up-qr-code';
import { useToast } from '@/hooks/use-toast';
import { createUserWithEmailAndPassword } from 'firebase/auth';
import { doc, setDoc } from 'firebase/firestore';
import { useAuth, useFirestore } from '@/firebase';

export default function SignupPage() {
  const [step, setStep] = useState(1);
  const [role, setRole] = useState<UserRole | null>(null);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [activationUtr, setActivationUtr] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  
  const router = useRouter();
  const { toast } = useToast();
  const auth = useAuth();
  const db = useFirestore();

  const handleRoleSelect = (selectedRole: UserRole) => {
    setRole(selectedRole);
    setStep(2);
  };

  const handleSignup = async (e: React.FormEvent) => {
    e.preventDefault();
    if (role === 'SHOPKEEPER' || role === 'COURIER') {
      setStep(3);
    } else {
      setIsLoading(true);
      try {
        if (!auth || !db) return;
        const userCredential = await createUserWithEmailAndPassword(auth, email, password);
        await setDoc(doc(db, 'users', userCredential.user.uid), {
          uid: userCredential.user.uid,
          email: email.toLowerCase(),
          displayName: name,
          phone,
          role: 'CUSTOMER',
          isVerified: true,
          walletBalance: 0,
          createdAt: new Date().toISOString()
        });
        
        toast({ title: "Registration Successful", description: "Welcome to Zingo!" });
        router.push('/customer/home');
      } catch (error: any) {
        console.error(error);
        toast({ variant: "destructive", title: "Error", description: error.message });
      } finally {
        setIsLoading(false);
      }
    }
  };

  const handleActivationSubmit = async () => {
    if (activationUtr.length < 12) {
      toast({ variant: "destructive", title: "Invalid UTR", description: "Please enter a valid 12-digit transaction ID." });
      return;
    }
    if (!auth || !db) return;
    setIsLoading(true);
    try {
      const userCredential = await createUserWithEmailAndPassword(auth, email, password);
      await setDoc(doc(db, 'users', userCredential.user.uid), {
        uid: userCredential.user.uid,
        email: email.toLowerCase(),
        displayName: name,
        phone,
        role: role,
        isVerified: false,
        activationUtr: activationUtr,
        walletBalance: 0,
        codCollected: 0,
        createdAt: new Date().toISOString()
      });

      toast({ 
        title: "Activation Submitted! 🚀", 
        description: "Admin will verify your payment and activate your account.",
      });
      router.push('/login');
    } catch (error: any) {
      console.error(error);
      toast({ variant: "destructive", title: "Error", description: error.message });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen gradient-bg flex items-center justify-center p-6">
      <Card className="w-full max-w-2xl cartoon-card border-none overflow-hidden">
        {step === 1 && (
          <>
            <CardHeader className="text-center p-12">
              <div className="flex justify-center mb-6">
                <div className="w-20 h-20 bg-accent rounded-[2.5rem] flex items-center justify-center shadow-2xl transform rotate-12 border-4 border-white">
                  <PartyPopper className="text-white w-10 h-10" />
                </div>
              </div>
              <h2 className="text-5xl font-black text-white tracking-tighter uppercase">JOIN THE SQUAD!</h2>
              <p className="text-indigo-100/60 font-black uppercase text-xs mt-2 tracking-widest">Who are you going to be today?</p>
            </CardHeader>
            <CardContent className="p-12 grid grid-cols-1 sm:grid-cols-3 gap-6">
              <RoleCard icon={ShoppingBag} title="Customer" desc="Buy cool stuff" onClick={() => handleRoleSelect('CUSTOMER')} />
              <RoleCard icon={Store} title="Shopkeeper" desc="Sell your goods" onClick={() => handleRoleSelect('SHOPKEEPER')} />
              <RoleCard icon={Truck} title="Courier" desc="Deliver & Earn" onClick={() => handleRoleSelect('COURIER')} />
            </CardContent>
          </>
        )}

        {step === 2 && (
          <>
            <CardHeader className="p-10 flex flex-row items-center gap-6">
              <Button variant="ghost" className="w-14 h-14 rounded-2xl bg-white/5" onClick={() => setStep(1)}>
                <ArrowLeft className="w-8 h-8" />
              </Button>
              <div>
                <h2 className="text-4xl font-black text-white tracking-tight uppercase">{role} RULES!</h2>
                <p className="text-indigo-100/60 font-black uppercase text-[10px] tracking-widest">Tell us about yourself</p>
              </div>
            </CardHeader>
            <CardContent className="p-10">
              <form onSubmit={handleSignup} className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <Label className="font-black text-[10px] uppercase tracking-widest text-white/60">Full Name</Label>
                    <Input placeholder="Your Name" className="h-14 bg-white/10 border-white/20 rounded-2xl font-bold" value={name} onChange={(e) => setName(e.target.value)} required />
                  </div>
                  <div className="space-y-2">
                    <Label className="font-black text-[10px] uppercase tracking-widest text-white/60">Phone Number</Label>
                    <Input placeholder="+91 00000 00000" className="h-14 bg-white/10 border-white/20 rounded-2xl font-bold" value={phone} onChange={(e) => setPhone(e.target.value)} required />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label className="font-black text-[10px] uppercase tracking-widest text-white/60">Email Address</Label>
                  <Input type="email" placeholder="you@zingo.com" className="h-14 bg-white/10 border-white/20 rounded-2xl font-bold" value={email} onChange={(e) => setEmail(e.target.value)} required />
                </div>
                <div className="space-y-2">
                  <Label className="font-black text-[10px] uppercase tracking-widest text-white/60">Password</Label>
                  <Input type="password" placeholder="••••••••" className="h-14 bg-white/10 border-white/20 rounded-2xl font-bold" value={password} onChange={(e) => setPassword(e.target.value)} required />
                </div>
                <Button type="submit" className="w-full h-20 text-2xl font-black rounded-[2rem] bg-primary border-b-8 border-primary-foreground/20 active:border-b-0 active:translate-y-1 mt-6 shadow-2xl">
                  {isLoading ? <Loader2 className="animate-spin" /> : role === 'CUSTOMER' ? "LET'S ROLL! 🚀" : "NEXT STEP ➡️"}
                </Button>
              </form>
            </CardContent>
          </>
        )}

        {step === 3 && (
          <>
            <CardHeader className="text-center p-10">
              <h2 className="text-4xl font-black text-white tracking-tighter uppercase">ACTIVATE BADGE! 🎖️</h2>
              <p className="text-indigo-100/60 font-black uppercase text-xs tracking-widest">
                Activation Fee: {role === 'SHOPKEEPER' ? '₹10' : '₹5'}
              </p>
            </CardHeader>
            <CardContent className="p-10 flex flex-col items-center gap-8">
              <UPIQRCode upiId={UPI_ID_ADMIN} amount={role === 'SHOPKEEPER' ? 10 : 5} transactionNote={`${role} Activation`} />
              <div className="w-full space-y-6">
                <div className="space-y-2 text-center">
                  <Label className="font-black text-[10px] uppercase tracking-widest text-white/60 block">Enter 12-Digit Transaction ID (UTR)</Label>
                  <Input 
                    placeholder="Enter UTR ID" 
                    className="h-16 bg-white/10 border-white/20 rounded-2xl text-center text-2xl font-mono tracking-widest" 
                    maxLength={12} 
                    value={activationUtr}
                    onChange={(e) => setActivationUtr(e.target.value)}
                  />
                </div>
                <Button onClick={handleActivationSubmit} className="w-full h-20 text-2xl font-black rounded-[2rem] bg-accent border-b-8 border-accent-foreground/20 active:border-b-0 active:translate-y-1 shadow-2xl" disabled={isLoading}>
                  {isLoading ? <Loader2 className="animate-spin" /> : "JOIN THE SQUAD! ✅"}
                </Button>
              </div>
            </CardContent>
          </>
        )}

        <CardFooter className="p-10 bg-black/20 justify-center">
           <span className="text-indigo-100/40 font-bold">Already part of Zingo? </span>
           <Link href="/login" className="text-primary font-black ml-2 hover:underline decoration-4">LOG IN</Link>
        </CardFooter>
      </Card>
    </div>
  );
}

function RoleCard({ icon: Icon, title, desc, onClick }: any) {
  return (
    <button onClick={onClick} className="flex flex-col items-center p-8 rounded-[2rem] bg-white/5 border-4 border-white/5 hover:bg-primary/20 hover:border-primary/50 transition-all group text-center active:scale-95">
      <div className="w-16 h-16 rounded-2xl bg-primary/10 flex items-center justify-center mb-6 group-hover:scale-125 transition-transform duration-500">
        <Icon className="w-10 h-10 text-primary" />
      </div>
      <h3 className="font-black text-2xl mb-2 text-white">{title}</h3>
      <p className="text-xs text-indigo-100/40 font-bold leading-tight uppercase">{desc}</p>
    </button>
  );
}
