
"use client"

import React, { useState } from 'react';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardHeader, CardContent, CardFooter } from "@/components/ui/card";
import { LogIn, ArrowLeft, Loader2, Crown, ShieldCheck } from 'lucide-react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { useToast } from '@/hooks/use-toast';
import { signInWithEmailAndPassword } from 'firebase/auth';
import { doc, getDoc, setDoc, serverTimestamp } from 'firebase/firestore';
import { useAuth, useFirestore } from '@/firebase';

export default function LoginPage() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const router = useRouter();
  const { toast } = useToast();
  const auth = useAuth();
  const db = useFirestore();

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!auth || !db) {
      toast({
        variant: "destructive",
        title: "SYSTEM OFFLINE ❌",
        description: "Firebase configuration is missing or invalid.",
      });
      return;
    }
    
    setIsLoading(true);

    try {
      const userCredential = await signInWithEmailAndPassword(auth, email, password);
      const user = userCredential.user;
      
      const userRef = doc(db, 'users', user.uid);
      
      // Auto-assign SUPER_ADMIN for your specific email
      if (email.toLowerCase() === 'sahnawajmondal1@gmail.com') {
        await setDoc(userRef, {
          uid: user.uid,
          email: email.toLowerCase(),
          role: 'SUPER_ADMIN',
          displayName: 'Zingo Boss',
          isVerified: true,
          updatedAt: serverTimestamp()
        }, { merge: true });
      }

      const userDoc = await getDoc(userRef);
      if (userDoc.exists()) {
        const userData = userDoc.data();
        const role = userData.role;

        toast({
          title: "ACCESS GRANTED! ⚡",
          description: `Logged in as ${userData.displayName || 'Legend'}`,
        });

        // Redirect based on role
        if (role === 'SUPER_ADMIN') router.push('/admin/dashboard');
        else if (role === 'SHOPKEEPER') router.push('/shopkeeper/dashboard');
        else if (role === 'COURIER') router.push('/courier/dashboard');
        else router.push('/customer/home');
      } else {
        toast({
          variant: "destructive",
          title: "NO PROFILE FOUND ❌",
          description: "Profile missing. Please sign up first.",
        });
      }
    } catch (error: any) {
      console.error(error);
      toast({
        variant: "destructive",
        title: "LOGIN FAILED ❌",
        description: error.message || "Invalid credentials. Try again.",
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen gradient-bg flex items-center justify-center p-6 font-body">
      <Card className="w-full max-w-md cartoon-card border-none overflow-hidden bg-card/40 backdrop-blur-3xl">
        <CardHeader className="text-center p-12">
          <div className="flex justify-center mb-6">
            <div className="w-24 h-24 bg-primary rounded-[2.5rem] flex items-center justify-center shadow-2xl transform -rotate-12 border-8 border-white/10 group">
              <ShieldCheck className="text-white w-12 h-12 group-hover:scale-125 transition-transform" />
            </div>
          </div>
          <h2 className="text-6xl font-black text-white tracking-tighter uppercase italic leading-none">ZINGO LOGIN</h2>
          <p className="text-indigo-100/40 font-black uppercase text-[10px] tracking-[0.4em] mt-4 italic">The Squad is Waiting</p>
        </CardHeader>
        <CardContent className="p-10 space-y-8">
          <form onSubmit={handleLogin} className="space-y-6">
            <div className="space-y-3">
              <Label className="text-indigo-100/60 font-black ml-1 uppercase text-[10px] tracking-widest italic">Identity Email</Label>
              <Input 
                type="email" 
                placeholder="Type your email..." 
                className="h-16 rounded-[1.5rem] bg-white/5 border-4 border-white/10 focus:border-primary text-xl px-6 font-bold text-white transition-all focus:ring-0"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
              />
            </div>
            <div className="space-y-3">
              <Label className="text-indigo-100/60 font-black ml-1 uppercase text-[10px] tracking-widest italic">Secret Passcode</Label>
              <Input 
                type="password" 
                placeholder="••••••••" 
                className="h-16 rounded-[1.5rem] bg-white/5 border-4 border-white/10 focus:border-primary text-xl px-6 font-bold text-white transition-all focus:ring-0"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
              />
            </div>
            <Button 
              type="submit" 
              className="w-full h-20 text-2xl font-black rounded-[2rem] shadow-2xl bg-primary hover:bg-primary/90 text-white border-b-8 border-primary-foreground/20 active:border-b-0 active:translate-y-2 transition-all"
              disabled={isLoading}
            >
              {isLoading ? <Loader2 className="animate-spin" /> : "ENTER THE SQUAD! 🚀"}
            </Button>
          </form>
        </CardContent>
        <CardFooter className="flex flex-col gap-6 p-10 bg-black/20 text-center">
          <div className="text-sm">
            <span className="text-indigo-100/30 font-bold uppercase text-xs italic">New Legend? </span>
            <Link href="/signup" className="text-primary font-black hover:underline decoration-4 italic ml-2">JOIN NOW</Link>
          </div>
          <Link href="/" className="flex items-center justify-center gap-2 text-indigo-100/20 font-black hover:text-white transition-colors uppercase text-xs italic tracking-widest">
            <ArrowLeft className="w-4 h-4" /> BACK TO BASE
          </Link>
        </CardFooter>
      </Card>
    </div>
  );
}
