"use client"

import React, { useState } from 'react';
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { ShoppingCart, LogIn, Store, Truck, ShieldCheck, ArrowRight } from 'lucide-react';
import Link from 'next/link';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';

export default function LandingPage() {
  const [showAuthModal, setShowAuthModal] = useState(false);

  const products = [
    { id: '1', name: 'Organic Milk', price: 65, shop: 'Deli Dairy', image: 'https://picsum.photos/seed/milk/400/300' },
    { id: '2', name: 'Fresh Breads', price: 40, shop: 'The Bakery', image: 'https://picsum.photos/seed/bread/400/300' },
    { id: '3', name: 'Farm Eggs', price: 120, shop: 'Poultry Farm', image: 'https://picsum.photos/seed/eggs/400/300' },
  ];

  const handleAction = () => {
    setShowAuthModal(true);
  };

  return (
    <div className="min-h-screen flex flex-col">
      {/* Hero Header */}
      <header className="p-6 md:p-12 gradient-bg relative overflow-hidden">
        <nav className="flex justify-between items-center mb-12 relative z-10">
          <div className="flex items-center gap-2">
            <div className="w-10 h-10 bg-white rounded-xl flex items-center justify-center shadow-lg">
              <span className="text-indigo-600 font-black text-xl">Z</span>
            </div>
            <span className="text-2xl font-black tracking-tighter text-white">ZINGO</span>
          </div>
          <div className="flex gap-4">
            <Button variant="ghost" className="text-white hover:bg-white/10" asChild>
              <Link href="/login">Login</Link>
            </Button>
            <Button className="bg-white text-indigo-600 hover:bg-white/90 font-bold" asChild>
              <Link href="/signup">Sign Up</Link>
            </Button>
          </div>
        </nav>

        <div className="relative z-10 max-w-2xl text-white">
          <h1 className="text-5xl md:text-7xl font-black leading-tight mb-6">
            Local Store. <br/>
            <span className="text-indigo-200">Rapid Delivery.</span>
          </h1>
          <p className="text-lg text-indigo-100/80 mb-8 max-w-lg">
            The premium shopping experience for your neighborhood. Order fresh groceries and essentials delivered to your door in minutes.
          </p>
          <div className="flex flex-wrap gap-4">
            <Button size="lg" className="bg-primary hover:bg-primary/90 text-white rounded-full px-8 shadow-xl" onClick={handleAction}>
              Start Shopping <ArrowRight className="ml-2 w-5 h-5" />
            </Button>
          </div>
        </div>
        
        <div className="absolute right-0 bottom-0 w-1/3 h-full opacity-20 pointer-events-none hidden lg:block">
           <Truck className="w-full h-full text-white" />
        </div>
      </header>

      {/* Featured Products */}
      <main className="flex-1 p-6 md:p-12 bg-background">
        <div className="flex justify-between items-end mb-8">
          <div>
            <h2 className="text-3xl font-bold mb-2">Popular Essentials</h2>
            <p className="text-muted-foreground">Nearby shops ready to deliver</p>
          </div>
          <Button variant="link" onClick={handleAction} className="text-primary font-bold">See All</Button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {products.map((p) => (
            <Card key={p.id} className="glass overflow-hidden group">
              <div className="relative h-48 overflow-hidden">
                <img src={p.image} alt={p.name} className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110" />
                <div className="absolute top-2 right-2">
                  <span className="bg-black/50 backdrop-blur-md text-white text-[10px] px-2 py-1 rounded-full font-bold">
                    {p.shop}
                  </span>
                </div>
              </div>
              <CardContent className="p-4">
                <div className="flex justify-between items-start mb-4">
                  <div>
                    <h3 className="font-bold text-lg">{p.name}</h3>
                    <p className="text-primary font-black text-xl">₹{p.price}</p>
                  </div>
                  <Button size="icon" variant="secondary" className="rounded-full h-10 w-10" onClick={handleAction}>
                    <ShoppingCart className="w-5 h-5" />
                  </Button>
                </div>
                <Button className="w-full font-bold" variant="outline" onClick={handleAction}>Buy Now</Button>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Value Props */}
        <section className="mt-20 grid grid-cols-1 md:grid-cols-3 gap-8 text-center">
           <div className="flex flex-col items-center gap-4 p-8 glass rounded-3xl">
             <div className="w-16 h-16 bg-primary/10 rounded-2xl flex items-center justify-center">
                <Store className="w-8 h-8 text-primary" />
             </div>
             <h4 className="text-xl font-bold">Local Partners</h4>
             <p className="text-sm text-muted-foreground">Support your neighborhood shops with our direct marketplace.</p>
           </div>
           <div className="flex flex-col items-center gap-4 p-8 glass rounded-3xl">
             <div className="w-16 h-16 bg-accent/10 rounded-2xl flex items-center justify-center">
                <Truck className="w-8 h-8 text-accent" />
             </div>
             <h4 className="text-xl font-bold">Fast Delivery</h4>
             <p className="text-sm text-muted-foreground">Professional couriers ensure your items arrive safely and fast.</p>
           </div>
           <div className="flex flex-col items-center gap-4 p-8 glass rounded-3xl">
             <div className="w-16 h-16 bg-green-500/10 rounded-2xl flex items-center justify-center">
                <ShieldCheck className="w-8 h-8 text-green-500" />
             </div>
             <h4 className="text-xl font-bold">Secure Payments</h4>
             <p className="text-sm text-muted-foreground">Advanced UPI double-routing for maximum transaction safety.</p>
           </div>
        </section>
      </main>

      {/* Footer */}
      <footer className="p-12 border-t border-white/5 text-center text-muted-foreground text-sm">
        <div className="flex items-center justify-center gap-2 mb-4">
            <div className="w-6 h-6 bg-primary rounded-md flex items-center justify-center">
              <span className="text-white font-black text-xs">Z</span>
            </div>
            <span className="text-lg font-black tracking-tighter text-foreground">ZINGO</span>
        </div>
        &copy; 2024 Zingo Technologies. All rights reserved.
      </footer>

      {/* Access Denied Modal */}
      <Dialog open={showAuthModal} onOpenChange={setShowAuthModal}>
        <DialogContent className="glass border-primary/20 sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="text-2xl font-black text-center mb-2">Access Denied!</DialogTitle>
            <DialogDescription className="text-center text-lg">
              Please Signup or Login to use this feature.
            </DialogDescription>
          </DialogHeader>
          <div className="flex flex-col gap-3 mt-4">
            <Button className="w-full h-12 text-lg font-bold" asChild>
              <Link href="/signup">Create Account</Link>
            </Button>
            <Button variant="outline" className="w-full h-12 text-lg font-bold" asChild>
              <Link href="/login">Existing User Login</Link>
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}