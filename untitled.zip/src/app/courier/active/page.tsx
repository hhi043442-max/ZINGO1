
"use client"

import React, { useState, useEffect } from 'react';
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Phone, MapPin, Package, QrCode, X, Zap, Banknote } from 'lucide-react';
import { BottomNav } from '@/components/layout/bottom-nav';
import { useCollection, useUser, useFirestore } from '@/firebase';
import { collection, query, where, updateDoc, doc, serverTimestamp, increment } from 'firebase/firestore';
import { useToast } from '@/hooks/use-toast';
import { cn } from '@/lib/utils';
import { COURIER_EARNING_PER_ORDER } from '@/lib/types';

export default function CourierActive() {
  const { user } = useUser();
  const db = useFirestore();
  const { toast } = useToast();
  const [showScanner, setShowScanner] = useState(false);
  const [activeScanningOrder, setActiveScanningOrder] = useState<string | null>(null);

  const activeQuery = React.useMemo(() => {
    if (!db || !user?.uid) return null;
    return query(
      collection(db, 'orders'), 
      where('courierId', '==', user.uid),
      where('status', 'in', ['ACCEPTED_BY_COURIER', 'PICKED_UP'])
    );
  }, [db, user?.uid]);

  const { data: orders, loading } = useCollection(activeQuery);

  useEffect(() => {
    let scanner: any = null;

    async function setupScanner() {
      if (showScanner && typeof window !== 'undefined') {
        const { Html5QrcodeScanner } = await import('html5-qrcode');
        scanner = new Html5QrcodeScanner("reader", { 
          fps: 10, 
          qrbox: { width: 250, height: 250 } 
        }, false);

        scanner.render((decodedText: string) => {
          handleScanSuccess(decodedText);
          if (scanner) scanner.clear();
        }, (error: any) => {});
      }
    }

    setupScanner();

    return () => {
      if (scanner) {
        scanner.clear().catch((e: any) => { console.error("Scanner clear error:", e); });
      }
    };
  }, [showScanner]);

  const handleScanSuccess = async (decodedText: string) => {
    if (!db || !activeScanningOrder || !user) return;
    
    const orderId = decodedText.replace('zingo_order_', '');
    
    if (orderId !== activeScanningOrder) {
      toast({ variant: "destructive", title: "INVALID QR!", description: "Doesn't match mission." });
      setShowScanner(false);
      return;
    }

    const order = orders?.find(o => o.id === orderId);
    if (!order) return;

    try {
      if (order.status === 'ACCEPTED_BY_COURIER') {
        await updateDoc(doc(db, 'orders', orderId), { 
          status: 'PICKED_UP',
          pickupAt: serverTimestamp()
        });
        toast({ title: "LOOT PICKED UP! 📦", description: "Head to the delivery coordinate." });
      } else if (order.status === 'PICKED_UP') {
        await updateDoc(doc(db, 'orders', orderId), { 
          status: 'DELIVERED',
          deliveredAt: serverTimestamp(),
          paymentStatus: 'PAID'
        });

        const userUpdates: any = {
           walletBalance: increment(COURIER_EARNING_PER_ORDER)
        };

        if (order.paymentMethod === 'COD') {
           userUpdates.codCollected = increment(order.totalAmount);
        }

        await updateDoc(doc(db, 'users', user.uid), userUpdates);

        toast({ title: "MISSION ACCOMPLISHED! 🏆", description: `Earnings: ₹${COURIER_EARNING_PER_ORDER} added.` });
      }
    } catch (e: any) {
      toast({ variant: "destructive", title: "Error", description: e.message });
    } finally {
      setShowScanner(false);
      setActiveScanningOrder(null);
    }
  };

  const startScanning = (orderId: string) => {
    setActiveScanningOrder(orderId);
    setShowScanner(true);
  };

  return (
    <div className="min-h-screen bg-background pb-32">
      <header className="p-8 gradient-bg rounded-b-[4rem] shadow-xl text-white">
        <h1 className="text-3xl font-black italic tracking-tighter">ACTIVE OPS 🎮</h1>
        <p className="text-indigo-100/60 font-black uppercase text-[10px] tracking-widest mt-1">Real-time Mission Control</p>
      </header>

      <div className="p-6 space-y-6">
        {loading ? (
          <div className="flex flex-col items-center justify-center py-20 gap-4">
            <Zap className="animate-spin text-primary w-12 h-12" />
            <p className="text-xs font-black uppercase italic text-primary">Syncing...</p>
          </div>
        ) : !orders || orders.length === 0 ? (
          <div className="text-center py-24 opacity-30 flex flex-col items-center gap-6">
            <Package className="w-20 h-20" />
            <p className="text-xl font-black italic uppercase">No active missions.</p>
          </div>
        ) : (
          orders.map((order: any) => (
            <Card key={order.id} className="cartoon-card border-none bg-card/40">
              <CardContent className="p-8">
                <div className="flex justify-between items-center mb-8">
                  <Badge className={cn(
                    "px-4 py-2 rounded-2xl font-black italic text-[10px] uppercase border-4",
                    order.status === 'PICKED_UP' ? "bg-accent border-black/20 text-black" : "bg-primary border-white/20"
                  )}>
                    {order.status.replace(/_/g, ' ')}
                  </Badge>
                  <p className="font-mono text-sm opacity-50">#ZNG-{order.id.slice(-6).toUpperCase()}</p>
                </div>

                <div className="space-y-6 mb-8">
                   <div className="flex gap-4 p-4 bg-white/5 rounded-2xl border-2 border-white/5">
                      <div className="w-12 h-12 rounded-2xl bg-primary/10 flex items-center justify-center shrink-0">
                         <Phone className="text-primary w-6 h-6" />
                      </div>
                      <div>
                         <p className="text-[10px] font-black uppercase opacity-40">Target Contact</p>
                         <p className="text-xl font-black italic">{order.customerPhone || 'Unknown'}</p>
                      </div>
                   </div>

                   <div className="flex gap-4 p-4 bg-green-500/10 rounded-2xl border-2 border-green-500/20">
                      <div className="w-12 h-12 rounded-2xl bg-green-500/10 flex items-center justify-center shrink-0">
                         <Banknote className="text-green-500 w-6 h-6" />
                      </div>
                      <div>
                         <p className="text-[10px] font-black uppercase opacity-40">Collection Goal</p>
                         <p className="text-3xl font-black italic text-green-500">
                           {order.paymentMethod === 'COD' ? `₹${order.totalAmount}` : 'ALREADY PAID'}
                         </p>
                      </div>
                   </div>

                   <div className="flex gap-4">
                      <div className="w-12 h-12 rounded-2xl bg-accent/10 flex items-center justify-center shrink-0">
                         <MapPin className="text-accent w-6 h-6" />
                      </div>
                      <div>
                         <p className="text-[10px] font-black uppercase opacity-40">Drop Zone</p>
                         <p className="text-lg font-black italic leading-tight">{order.deliveryAddress}</p>
                      </div>
                   </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <a href={`tel:${order.customerPhone}`} className="flex-1">
                    <Button variant="outline" className="w-full h-16 rounded-2xl border-4 bg-white/5 font-black italic">
                      <Phone className="w-5 h-5 mr-2" /> CALL TARGET
                    </Button>
                  </a>
                  <Button 
                    className={cn(
                      "h-16 rounded-2xl font-black italic text-xl border-b-8 shadow-2xl",
                      order.status === 'PICKED_UP' ? "bg-green-500 border-green-700" : "bg-primary border-indigo-700"
                    )}
                    onClick={() => startScanning(order.id)}
                  >
                    <QrCode className="w-6 h-6 mr-2" /> {order.status === 'PICKED_UP' ? "DELIVER" : "PICK UP"}
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))
        )}
      </div>

      {showScanner && (
        <div className="fixed inset-0 z-[100] bg-black/95 backdrop-blur-3xl flex flex-col items-center justify-center p-8">
           <Button variant="ghost" size="icon" className="absolute top-8 right-8 z-20" onClick={() => setShowScanner(false)}>
             <X className="w-10 h-10 text-white" />
           </Button>
           <div className="w-full max-w-md p-8 bg-card rounded-[3rem] border-8 border-primary shadow-2xl">
              <h3 className="text-3xl font-black italic text-center mb-8 uppercase">SCAN ORDER QR 🤳</h3>
              <div id="reader" className="w-full overflow-hidden rounded-[2rem] border-4 border-white/10" />
           </div>
        </div>
      )}

      <BottomNav role="COURIER" />
    </div>
  );
}
