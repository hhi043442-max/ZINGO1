
"use client"

import React, { useState, useMemo } from 'react';
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Wallet, ArrowUpRight, History, CreditCard, Clock, Banknote, QrCode, Loader2, CheckCircle } from 'lucide-react';
import { BottomNav } from '@/components/layout/bottom-nav';
import { useDoc, useUser, useFirestore, useCollection } from '@/firebase';
import { doc, addDoc, collection, serverTimestamp, updateDoc } from 'firebase/firestore';
import { useToast } from '@/hooks/use-toast';
import { UPIQRCode } from '@/components/ui/up-qr-code';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { COURIER_MIN_WITHDRAW, COURIER_COD_LIMIT, UPI_ID_ADMIN } from '@/lib/types';

export default function CourierWallet() {
  const { user } = useUser();
  const db = useFirestore();
  const { toast } = useToast();
  
  const [showWithdraw, setShowWithdraw] = useState(false);
  const [showSettle, setShowSettle] = useState(false);
  const [withdrawAmount, setWithdrawAmount] = useState('');
  const [withdrawUpi, setWithdrawUpi] = useState('');
  const [utrId, setUtrId] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  const userRef = useMemo(() => user && db ? doc(db, 'users', user.uid) : null, [db, user]);
  const { data: userData } = useDoc(userRef);

  const handleWithdraw = async () => {
    const amount = Number(withdrawAmount);
    if (amount < COURIER_MIN_WITHDRAW) {
      toast({ variant: "destructive", title: "Limit Too Low!", description: `Min withdraw is ₹${COURIER_MIN_WITHDRAW}` });
      return;
    }
    if (amount > (userData?.walletBalance || 0)) {
      toast({ variant: "destructive", title: "Insufficient Funds!", description: "You don't have enough gold." });
      return;
    }
    if (!withdrawUpi) {
      toast({ variant: "destructive", title: "UPI ID Missing!" });
      return;
    }

    setIsSubmitting(true);
    try {
      await addDoc(collection(db!, 'payout_requests'), {
        userId: user!.uid,
        userName: userData!.displayName,
        userRole: 'COURIER',
        amount: amount,
        upiId: withdrawUpi,
        status: 'PENDING',
        createdAt: serverTimestamp()
      });
      
      // Reduce balance immediately for safety (optimistic)
      await updateDoc(userRef!, {
        walletBalance: (userData?.walletBalance || 0) - amount
      });

      toast({ title: "WITHDRAWAL REQUESTED! 🚀", description: "Admin will process your payment soon." });
      setShowWithdraw(false);
    } catch (e: any) {
      console.error(e);
      toast({ variant: "destructive", title: "Request Failed", description: e.message });
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleSettleDebt = async () => {
    if (utrId.length < 12) {
      toast({ variant: "destructive", title: "Invalid UTR!", description: "Enter 12-digit transaction ID." });
      return;
    }

    setIsSubmitting(true);
    try {
      await addDoc(collection(db!, 'debt_settlements'), {
        userId: user!.uid,
        userName: userData!.displayName,
        amount: userData!.codCollected,
        transactionId: utrId,
        status: 'PENDING',
        createdAt: serverTimestamp()
      });

      toast({ title: "SETTLEMENT SUBMITTED! ✅", description: "Admin will verify and unblock your account." });
      setShowSettle(false);
    } catch (e: any) {
      console.error(e);
      toast({ variant: "destructive", title: "Failed", description: e.message });
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen bg-background pb-32 font-body">
      <header className="p-8 gradient-bg rounded-b-[4rem] text-white shadow-2xl">
        <h1 className="text-3xl font-black italic uppercase">Hero Treasury 💰</h1>
        <p className="text-indigo-100/60 font-black uppercase text-[10px] tracking-widest mt-1">Manage your gold and debts</p>
      </header>

      <div className="p-8 space-y-8">
        {/* Wallet Card */}
        <Card className="cartoon-card border-none bg-card/40 p-8 text-center relative overflow-hidden">
           <div className="relative z-10">
              <p className="text-[10px] font-black uppercase opacity-40 italic tracking-widest">Available Balance</p>
              <h2 className="text-6xl font-black italic text-white my-4">₹{userData?.walletBalance || 0}</h2>
              <Button 
                onClick={() => setShowWithdraw(true)}
                className="w-full h-16 rounded-2xl bg-primary font-black italic text-xl border-b-8 border-indigo-700 shadow-2xl active:translate-y-2 transition-all"
              >
                WITHDRAW GOLD 🚀
              </Button>
           </div>
           <Wallet className="absolute -right-8 -bottom-8 w-32 h-32 text-white/5 rotate-12" />
        </Card>

        {/* COD Debt Card */}
        <Card className="cartoon-card border-none bg-destructive/10 border-2 border-destructive/20 p-8">
           <div className="flex justify-between items-center mb-6">
              <div>
                 <p className="text-[10px] font-black uppercase opacity-40 italic text-destructive tracking-widest">COD Debt (Held Cash)</p>
                 <h2 className="text-4xl font-black italic text-destructive">₹{userData?.codCollected || 0}</h2>
              </div>
              <div className="w-12 h-12 bg-destructive/20 rounded-2xl flex items-center justify-center">
                 <Banknote className="text-destructive w-6 h-6" />
              </div>
           </div>
           <div className="space-y-4">
              <p className="text-xs font-bold text-white/40 italic">Block limit: ₹{COURIER_COD_LIMIT}. Settle now to avoid mission block.</p>
              <Button 
                onClick={() => setShowSettle(true)}
                variant="outline"
                className="w-full h-14 rounded-2xl border-4 border-destructive/20 bg-destructive/10 font-black italic text-destructive hover:bg-destructive hover:text-white"
              >
                SETTLE ADMIN DEBT 💳
              </Button>
           </div>
        </Card>
      </div>

      {/* Withdraw Dialog */}
      <Dialog open={showWithdraw} onOpenChange={setShowWithdraw}>
         <DialogContent className="glass border-primary rounded-[3rem] p-8 max-w-md">
            <DialogHeader><DialogTitle className="text-3xl font-black italic uppercase text-center">PAYOUT MISSION 🗺️</DialogTitle></DialogHeader>
            <div className="space-y-6 pt-6">
               <div className="space-y-2">
                  <Label className="font-black italic text-[10px] uppercase opacity-40 tracking-widest">Amount to Withdraw (Min ₹{COURIER_MIN_WITHDRAW})</Label>
                  <Input 
                    type="number" 
                    placeholder="Enter Amount" 
                    className="h-16 bg-white/5 border-4 rounded-2xl font-black text-2xl text-center" 
                    value={withdrawAmount}
                    onChange={(e) => setWithdrawAmount(e.target.value)}
                  />
               </div>
               <div className="space-y-2">
                  <Label className="font-black italic text-[10px] uppercase opacity-40 tracking-widest">Target UPI ID</Label>
                  <Input 
                    placeholder="hero@upi" 
                    className="h-16 bg-white/5 border-4 rounded-2xl font-black text-xl text-center" 
                    value={withdrawUpi}
                    onChange={(e) => setWithdrawUpi(e.target.value)}
                  />
               </div>
               <Button 
                 onClick={handleWithdraw}
                 disabled={isSubmitting}
                 className="w-full h-20 rounded-[2rem] bg-primary font-black italic text-2xl border-b-8 shadow-2xl active:translate-y-2"
               >
                 {isSubmitting ? <Loader2 className="animate-spin" /> : "SEND REQUEST! 🚀"}
               </Button>
            </div>
         </DialogContent>
      </Dialog>

      {/* Settle Dialog */}
      <Dialog open={showSettle} onOpenChange={setShowSettle}>
         <DialogContent className="glass border-destructive rounded-[3rem] p-8 max-w-md">
            <DialogHeader><DialogTitle className="text-3xl font-black italic uppercase text-center">DEBT SETTLEMENT 🔎</DialogTitle></DialogHeader>
            <div className="space-y-8 pt-6 flex flex-col items-center">
               <UPIQRCode upiId={UPI_ID_ADMIN} amount={userData?.codCollected} transactionNote="Zingo Debt Settle" />
               <div className="w-full space-y-2">
                  <Label className="font-black italic text-[10px] uppercase opacity-40 tracking-widest text-center block">Enter Transaction ID (UTR)</Label>
                  <Input 
                    maxLength={12}
                    placeholder="12-digit Ref ID" 
                    className="h-16 bg-white/10 border-4 border-destructive rounded-2xl text-center text-2xl font-mono tracking-widest" 
                    value={utrId}
                    onChange={(e) => setUtrId(e.target.value)}
                  />
               </div>
               <Button 
                 onClick={handleSettleDebt}
                 disabled={isSubmitting}
                 className="w-full h-20 rounded-[2rem] bg-destructive font-black italic text-2xl border-b-8 border-red-900 shadow-2xl active:translate-y-2"
               >
                 {isSubmitting ? <Loader2 className="animate-spin" /> : "SUBMIT FOR VERIFY ✅"}
               </Button>
            </div>
         </DialogContent>
      </Dialog>

      <BottomNav role="COURIER" />
    </div>
  );
}
