
"use client"

import React, { useMemo } from 'react';
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Navigation, Wallet, Package, Zap, MapPin, User, Star, TrendingUp, AlertTriangle, ShieldAlert, Loader2 } from 'lucide-react';
import { BottomNav } from '@/components/layout/bottom-nav';
import { useCollection, useUser, useFirestore, useDoc } from '@/firebase';
import { collection, query, where, updateDoc, doc } from 'firebase/firestore';
import { useToast } from '@/hooks/use-toast';
import { cn } from '@/lib/utils';
import { COURIER_COD_LIMIT } from '@/lib/types';

export default function CourierDashboard() {
  const { user } = useUser();
  const db = useFirestore();
  const { toast } = useToast();

  const userRef = useMemo(() => user && db ? doc(db, 'users', user.uid) : null, [db, user]);
  const { data: userData, loading: userLoading } = useDoc(userRef);

  const availableQuery = useMemo(() => {
    if (!db) return null;
    return query(collection(db, 'orders'), where('status', '==', 'READY_FOR_PICKUP'));
  }, [db]);

  const { data: availableOrders, loading } = useCollection(availableQuery);

  if (userLoading) return <div className="min-h-screen flex items-center justify-center bg-background"><Loader2 className="animate-spin w-20 h-20 text-primary" /></div>;

  if (userData && !userData.isVerified) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center p-8 font-body">
        <Card className="cartoon-card max-w-md p-10 text-center space-y-8 bg-accent/10 border-accent">
          <div className="w-24 h-24 bg-accent/20 rounded-[2rem] flex items-center justify-center mx-auto animate-pulse">
            <ShieldAlert className="text-accent w-12 h-12" />
          </div>
          <div>
            <h2 className="text-4xl font-black italic text-accent uppercase tracking-tighter leading-none">Hero In Training!</h2>
            <p className="text-white/60 font-bold mt-4 italic">
              Your activation request (UTR: <span className="text-white font-mono">{userData.activationUtr}</span>) is under review.
            </p>
          </div>
          <p className="text-[10px] font-black uppercase tracking-widest opacity-40">The Zingo Squad is verifying your badge.</p>
          <Button variant="outline" className="w-full h-14 rounded-2xl border-4" onClick={() => window.location.reload()}>SYNC DATA 🔎</Button>
        </Card>
      </div>
    );
  }

  const isDebtLimitReached = (userData?.codCollected || 0) >= COURIER_COD_LIMIT;

  const handleAcceptOrder = async (orderId: string) => {
    if (isDebtLimitReached) {
      toast({ 
        variant: "destructive", 
        title: "DEBT LIMIT REACHED! 🛑", 
        description: "Pay your collected COD cash to Admin to unblock." 
      });
      return;
    }
    if (!db || !user) return;
    try {
      await updateDoc(doc(db, 'orders', orderId), {
        status: 'ACCEPTED_BY_COURIER',
        courierId: user.uid
      });
      toast({ title: "MISSION ACCEPTED! 🚀", description: "Navigate to the store for pickup." });
    } catch (e: any) {
      console.error(e);
      toast({ variant: "destructive", title: "Failed to Accept", description: e.message });
    }
  };

  return (
    <div className="min-h-screen bg-background pb-32 font-body overflow-x-hidden">
      <header className="p-8 gradient-bg rounded-b-[4rem] shadow-2xl relative overflow-hidden">
        <div className="relative z-10 flex justify-between items-center mb-12">
           <div className="flex items-center gap-4">
              <div className="w-20 h-20 rounded-[2rem] bg-white/20 backdrop-blur-md flex items-center justify-center border-4 border-white/20 shadow-2xl transform -rotate-6">
                 <User className="text-white w-10 h-10" />
              </div>
              <div className="text-white">
                 <h2 className="text-4xl font-black italic tracking-tighter leading-none">{userData?.displayName || 'Hero'}</h2>
                 <p className="text-[10px] text-accent font-black uppercase tracking-[0.3em] mt-2 italic">Rank: Top Gun Elite</p>
              </div>
           </div>
           <Badge className="bg-green-500 h-10 px-4 rounded-full font-black border-4 border-white animate-pulse uppercase italic">Live</Badge>
        </div>

        <div className="grid grid-cols-2 gap-6 relative z-10">
           <Card className="bg-white/10 backdrop-blur-xl p-8 rounded-[2.5rem] border-4 border-white/10 shadow-2xl">
              <p className="text-[10px] text-indigo-100/60 font-black uppercase tracking-widest mb-2 italic">Earnings</p>
              <div className="flex items-end gap-1">
                <span className="text-4xl font-black text-white italic">₹{userData?.walletBalance || 0}</span>
                <TrendingUp className="w-5 h-5 text-accent mb-2" />
              </div>
           </Card>
           <Card className={cn(
             "bg-white/10 backdrop-blur-xl p-8 rounded-[2.5rem] border-4 shadow-2xl",
             isDebtLimitReached ? "border-destructive animate-pulse" : "border-white/10"
           )}>
              <p className="text-[10px] text-indigo-100/60 font-black uppercase tracking-widest mb-2 italic">COD Held</p>
              <span className={cn("text-4xl font-black italic", isDebtLimitReached ? "text-destructive" : "text-white")}>
                ₹{userData?.codCollected || 0}
              </span>
           </Card>
        </div>
      </header>

      <div className="p-8 space-y-10">
        {isDebtLimitReached && (
          <Card className="cartoon-card bg-destructive/20 border-destructive p-8 flex flex-col items-center text-center gap-4">
            <AlertTriangle className="w-16 h-16 text-destructive animate-bounce" />
            <h3 className="text-3xl font-black italic text-destructive uppercase">ACCOUNT BLOCKED!</h3>
            <p className="font-bold text-white/60">You have collected over ₹{COURIER_COD_LIMIT} in cash. Pay back Admin to continue missions.</p>
            <Button className="bg-destructive text-white font-black h-14 rounded-2xl w-full" onClick={() => window.location.href='/courier/wallet'}>
              SETTLE DEBT NOW
            </Button>
          </Card>
        )}

        <div className="flex justify-between items-center">
          <h3 className="text-4xl font-black italic uppercase tracking-tighter">Available Jobs 🎯</h3>
          <div className="w-12 h-12 rounded-2xl bg-primary/10 flex items-center justify-center animate-bounce">
             <Package className="text-primary" />
          </div>
        </div>

        {loading ? (
          <div className="flex justify-center py-10"><Zap className="animate-spin text-primary w-12 h-12" /></div>
        ) : !availableOrders || availableOrders.length === 0 ? (
          <Card className="cartoon-card border-none bg-card/40 p-16 text-center opacity-30">
            <Package className="w-20 h-20 mx-auto mb-6" />
            <p className="text-xl font-black italic uppercase">The map is clear. Stand by for orders.</p>
          </Card>
        ) : (
          <div className="space-y-6">
            {availableOrders.map((order: any) => (
              <Card key={order.id} className="cartoon-card border-none bg-card/40 p-8 hover:translate-x-3 transition-all cursor-pointer group">
                 <div className="flex justify-between items-start mb-6">
                    <div>
                       <p className="text-[10px] text-primary font-black uppercase tracking-widest mb-1 italic">New Mission Alert</p>
                       <h4 className="text-2xl font-black italic text-white uppercase tracking-tighter">#ZNG-{order.id.slice(-6).toUpperCase()}</h4>
                    </div>
                    <div className="text-right">
                       <span className="text-3xl font-black text-accent italic leading-none">₹5.00</span>
                       <p className="text-[8px] font-black opacity-40 uppercase">Earning</p>
                    </div>
                 </div>
                 
                 <div className="space-y-4 mb-8 pt-4 border-t border-white/5">
                    <div className="flex items-center gap-3">
                       <Navigation className="text-accent w-5 h-5" />
                       <span className="text-sm font-bold text-indigo-100/60 italic">Collect at Store Hub</span>
                    </div>
                    <div className="flex items-center gap-3">
                       <MapPin className="text-accent w-5 h-5" />
                       <span className="text-sm font-bold text-indigo-100/60 italic truncate">Drop: {order.deliveryAddress}</span>
                    </div>
                 </div>

                 <Button 
                   onClick={() => handleAcceptOrder(order.id)}
                   className="w-full h-16 rounded-2xl bg-primary text-xl font-black italic border-b-8 shadow-2xl active:translate-y-2 transition-all"
                   disabled={isDebtLimitReached}
                 >
                    {isDebtLimitReached ? "BLOCKED 🔒" : "ACCEPT MISSION! 🚀"}
                 </Button>
              </Card>
            ))}
          </div>
        )}
      </div>

      <BottomNav role="COURIER" />
    </div>
  );
}
