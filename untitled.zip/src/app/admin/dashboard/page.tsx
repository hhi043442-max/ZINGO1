
"use client"

import React from 'react';
import { Card, CardHeader, CardContent, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { 
  LayoutDashboard, 
  Users, 
  ShieldCheck, 
  Wallet, 
  LogOut,
  Menu,
  Sparkles,
  Zap,
  Star,
  Crown,
  Bell,
  CreditCard,
  Banknote
} from 'lucide-react';
import { cn } from '@/lib/utils';
import Link from 'next/link';
import { useAuth, useUser } from '@/firebase';
import { signOut } from 'firebase/auth';
import { useRouter, usePathname } from 'next/navigation';
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetTrigger } from '@/components/ui/sheet';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip as ChartTooltip, ResponsiveContainer } from 'recharts';

const profitData = [
  { name: 'M', p: 400 },
  { name: 'T', p: 700 },
  { name: 'W', p: 500 },
  { name: 'T', p: 900 },
  { name: 'F', p: 1400 },
  { name: 'S', p: 1600 },
  { name: 'S', p: 1200 },
];

export default function AdminDashboard() {
  const auth = useAuth();
  const { user } = useUser();
  const router = useRouter();
  const pathname = usePathname();

  const handleLogout = async () => {
    try {
      if (auth) await signOut(auth);
    } catch (e) { console.error("Logout error:", e); }
    router.push('/login');
  };

  const SidebarContent = () => (
    <div className="flex flex-col h-full p-8 bg-card border-r-8 border-white/5">
      <div className="flex items-center gap-4 mb-16 px-4">
          <div className="w-16 h-16 bg-primary rounded-[2rem] flex items-center justify-center shadow-2xl transform -rotate-12 border-4 border-white">
            <Crown className="text-white w-8 h-8" />
          </div>
          <div>
            <span className="text-3xl font-black tracking-tighter block leading-none italic uppercase">ZINGO</span>
            <span className="text-[10px] font-black text-primary uppercase tracking-[0.3em] italic">Boss Mode</span>
          </div>
      </div>
      
      <nav className="flex-1 space-y-4">
         <SidebarItem icon={LayoutDashboard} label="The Control" active={pathname === '/admin/dashboard'} href="/admin/dashboard" />
         <SidebarItem icon={CreditCard} label="Verify Orders" active={pathname === '/admin/verifications'} href="/admin/verifications" />
         <SidebarItem icon={Banknote} label="Payout Hub" active={pathname === '/admin/payouts'} href="/admin/payouts" />
         <SidebarItem icon={Users} label="The Squad" active={pathname === '/admin/staff'} href="/admin/staff" />
         <SidebarItem icon={ShieldCheck} label="Merchant Check" active={pathname === '/admin/merchants'} href="/admin/merchants" />
         <SidebarItem icon={Wallet} label="The Treasury" active={pathname === '/admin/wallet'} href="/admin/wallet" />
      </nav>

      <div className="mt-auto pt-8 border-t-8 border-white/5">
         <Button variant="ghost" className="w-full h-16 rounded-[1.5rem] justify-start text-destructive hover:bg-destructive/10 font-black text-xl italic border-4 border-transparent hover:border-destructive/20" onClick={handleLogout}>
            <LogOut className="w-6 h-6 mr-4" /> GET OUT
         </Button>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen bg-background flex font-body overflow-x-hidden">
      <aside className="hidden md:flex flex-col w-80 glass border-r-8 border-white/5 h-screen sticky top-0">
        <SidebarContent />
      </aside>

      <main className="flex-1 p-6 md:p-12 overflow-y-auto w-full">
        <div className="md:hidden flex justify-between items-center mb-10">
          <Sheet>
            <SheetTrigger asChild>
              <Button size="icon" className="w-14 h-14 rounded-2xl glass border-4 active:scale-90 transition-transform">
                <Menu className="w-8 h-8 text-primary" />
              </Button>
            </SheetTrigger>
            <SheetContent side="left" className="glass border-white/10 p-0 w-80">
               <SheetHeader className="sr-only"><SheetTitle>Navigation Menu</SheetTitle></SheetHeader>
               <SidebarContent />
            </SheetContent>
          </Sheet>
          <div className="flex items-center gap-2"><span className="text-2xl font-black italic">ZINGO</span></div>
        </div>

        <div className="mb-16">
           <h1 className="text-6xl md:text-8xl font-black leading-none tracking-tighter uppercase italic">
              Big <span className="text-primary underline underline-offset-8">Money</span><br/>Energy.
           </h1>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8 mb-16">
           <StatsCard label="Net Gold" value="₹4.2L" color="primary" icon={Star} />
           <StatsCard label="Shop Cuts" value="₹12K" color="accent" icon={Zap} />
           <StatsCard label="Payouts" value="Pending" color="indigo" icon={Banknote} />
           <StatsCard label="Power" value="99%" color="primary" icon={Crown} />
        </div>

        <div className="grid grid-cols-1 xl:grid-cols-2 gap-10">
           <Card className="cartoon-card p-10">
              <div className="h-[350px]">
                <ResponsiveContainer width="100%" height="100%">
                   <BarChart data={profitData}>
                      <CartesianGrid strokeDasharray="3 3" stroke="#1f2937" vertical={false} />
                      <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{fill: '#9ca3af', fontSize: 14, fontWeight: '900'}} />
                      <YAxis axisLine={false} tickLine={false} tick={{fill: '#9ca3af', fontSize: 14, fontWeight: '900'}} />
                      <ChartTooltip contentStyle={{backgroundColor: '#0f0c19', borderRadius: '30px', border: '4px solid #7a63ff', padding: '20px'}} />
                      <Bar dataKey="p" fill="#7a63ff" radius={[15, 15, 0, 0]} />
                   </BarChart>
                </ResponsiveContainer>
              </div>
           </Card>

           <Card className="cartoon-card-accent p-10 flex flex-col items-center justify-center text-center gap-6">
              <Banknote className="w-20 h-20 text-accent animate-pulse" />
              <h3 className="text-4xl font-black italic">PAYOUT HUB</h3>
              <p className="font-bold opacity-60">Shopkeepers and Couriers are requesting settlements.</p>
              <Link href="/admin/payouts" className="w-full">
                <Button className="w-full h-16 rounded-2xl text-xl font-black italic shadow-2xl bg-accent hover:bg-accent/90">GO TO HUB 🏦</Button>
              </Link>
           </Card>
        </div>
      </main>
    </div>
  );
}

function SidebarItem({ icon: Icon, label, active = false, href = "#" }: any) {
  return (
    <Link href={href} className="block group">
      <div className={cn(
        "w-full flex items-center gap-5 px-6 py-5 rounded-[2.5rem] transition-all duration-300 font-black text-xl border-4 italic cursor-pointer",
        active ? "bg-primary text-white border-white shadow-xl scale-[1.05]" : "text-muted-foreground border-transparent hover:bg-white/5 hover:text-foreground"
      )}>
         <Icon className="w-7 h-7" /> {label}
      </div>
    </Link>
  );
}

function StatsCard({ label, value, color, icon: Icon }: any) {
  const colorMap: any = {
    primary: 'text-primary bg-primary/10 border-primary/20',
    accent: 'text-accent bg-accent/10 border-accent/20',
    indigo: 'text-indigo-400 bg-indigo-400/10 border-indigo-400/20',
  };
  return (
    <Card className={cn("cartoon-card border-4 overflow-hidden group hover:-translate-y-4 transition-all duration-500", colorMap[color])}>
       <CardContent className="p-8">
          <Icon className="w-10 h-10 mb-6" />
          <p className="text-[10px] font-black uppercase tracking-[0.4em] mb-3 opacity-50 italic">{label}</p>
          <h3 className="text-4xl font-black tracking-tighter text-white italic">{value}</h3>
       </CardContent>
    </Card>
  );
}
