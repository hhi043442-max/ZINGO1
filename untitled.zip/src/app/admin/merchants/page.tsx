
"use client"

import React from 'react';
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ShieldCheck, UserX, CheckCircle, Loader2, CreditCard, User } from 'lucide-react';
import { useCollection, useFirestore } from '@/firebase';
import { collection, query, where, updateDoc, doc } from 'firebase/firestore';
import { useToast } from '@/hooks/use-toast';
import Link from 'next/link';
import { cn } from '@/lib/utils';

export default function AdminMerchants() {
  const db = useFirestore();
  const { toast } = useToast();

  const pendingQuery = React.useMemo(() => {
    if (!db) return null;
    return query(collection(db, 'users'), where('isVerified', '==', false));
  }, [db]);

  const { data: pendingUsers, loading } = useCollection(pendingQuery);

  const handleApprove = async (userId: string) => {
    if (!db) return;
    try {
      await updateDoc(doc(db, 'users', userId), { 
        isVerified: true 
      });
      toast({ title: "Hero Activated! 🎖️", description: "Merchant/Courier can now access their dashboard." });
    } catch (error: any) {
      console.error(error);
      toast({ variant: "destructive", title: "Error", description: error.message });
    }
  };

  return (
    <div className="min-h-screen bg-background p-6 md:p-12 font-body">
      <div className="flex items-center gap-6 mb-12">
        <Link href="/admin/dashboard">
          <Button variant="ghost" size="icon" className="w-14 h-14 rounded-2xl glass border-4">
            <UserX className="w-8 h-8" />
          </Button>
        </Link>
        <div>
          <h1 className="text-4xl font-black italic uppercase tracking-tighter">Activation Hub 🔎</h1>
          <p className="text-muted-foreground font-bold italic opacity-60">Verify UTR IDs and Activate New Squad Members</p>
        </div>
      </div>

      {loading ? (
        <div className="flex justify-center p-20"><Loader2 className="animate-spin text-primary w-16 h-16" /></div>
      ) : !pendingUsers || pendingUsers.length === 0 ? (
        <Card className="cartoon-card p-20 text-center opacity-40">
          <ShieldCheck className="w-20 h-20 mx-auto mb-6" />
          <p className="text-2xl font-black italic">NO PENDING ACTIVATIONS.</p>
        </Card>
      ) : (
        <div className="grid gap-8">
          {pendingUsers.map((user: any) => (
            <Card key={user.id} className="cartoon-card border-none bg-card/40 p-10 hover:scale-[1.01] transition-all">
              <div className="flex flex-col md:flex-row justify-between gap-10">
                <div className="flex-1 space-y-6">
                  <div className="flex items-center gap-4">
                    <div className={cn(
                      "w-12 h-12 rounded-xl flex items-center justify-center border-2",
                      user.role === 'COURIER' ? "bg-accent/20 border-accent/20 text-accent" : "bg-primary/20 border-primary/20 text-primary"
                    )}>
                      <User />
                    </div>
                    <div>
                      <p className="text-[10px] font-black uppercase opacity-40 italic tracking-widest">{user.role} REQUEST</p>
                      <h4 className="text-3xl font-black italic uppercase">{user.displayName}</h4>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 p-6 bg-white/5 rounded-3xl border-2 border-white/5">
                    <div>
                       <p className="text-[10px] font-black uppercase opacity-40 mb-1">Activation UTR</p>
                       <p className="text-3xl font-black text-accent tracking-[0.2em] font-mono">{user.activationUtr || 'N/A'}</p>
                    </div>
                    <div>
                       <p className="text-[10px] font-black uppercase opacity-40 mb-1">Contact Email</p>
                       <p className="text-sm font-bold text-white truncate">{user.email}</p>
                    </div>
                  </div>
                </div>

                <div className="flex flex-row md:flex-col gap-4 justify-center shrink-0">
                  <Button variant="outline" className="h-16 px-8 rounded-2xl border-4 font-black italic">REJECT</Button>
                  <Button 
                    className="h-16 px-8 rounded-2xl bg-green-500 hover:bg-green-600 font-black italic border-b-8 border-green-800 active:translate-y-1 shadow-2xl"
                    onClick={() => handleApprove(user.id)}
                  >
                    <CheckCircle className="mr-2" /> ACTIVATE HERO
                  </Button>
                </div>
              </div>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
