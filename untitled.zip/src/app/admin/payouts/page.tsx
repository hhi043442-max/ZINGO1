
"use client"

import React from 'react';
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Banknote, CheckCircle, XCircle, ArrowLeft, Loader2, User } from 'lucide-react';
import { useCollection, useFirestore } from '@/firebase';
import { collection, query, where, updateDoc, doc, increment } from 'firebase/firestore';
import { useToast } from '@/hooks/use-toast';
import Link from 'next/link';
import { cn } from '@/lib/utils';

export default function AdminPayouts() {
  const db = useFirestore();
  const { toast } = useToast();

  const payoutQuery = React.useMemo(() => {
    if (!db) return null;
    return query(collection(db, 'payout_requests'), where('status', '==', 'PENDING'));
  }, [db]);

  const { data: payouts, loading } = useCollection(payoutQuery);

  const handleAction = async (payout: any, approve: boolean) => {
    if (!db) return;
    try {
      await updateDoc(doc(db, 'payout_requests', payout.id), { 
        status: approve ? 'PAID' : 'REJECTED'
      });
      
      if (!approve) {
        // Refund the balance back to user if rejected
        await updateDoc(doc(db, 'users', payout.userId), {
          walletBalance: increment(payout.amount)
        });
      }
      
      toast({ title: approve ? "Payout Marked as Paid! 💰" : "Payout Rejected and Refunded ❌" });
    } catch (e: any) {
      console.error(e);
      toast({ variant: "destructive", title: "Action Failed", description: e.message });
    }
  };

  return (
    <div className="min-h-screen bg-background p-6 md:p-12 font-body">
      <div className="flex items-center gap-6 mb-12">
        <Link href="/admin/dashboard">
          <Button variant="ghost" size="icon" className="w-14 h-14 rounded-2xl glass border-4">
            <ArrowLeft className="w-8 h-8" />
          </Button>
        </Link>
        <div>
          <h1 className="text-4xl font-black italic uppercase">Payout Hub 🏦</h1>
          <p className="text-muted-foreground font-bold italic opacity-60">Process withdrawal requests for Couriers and Shops</p>
        </div>
      </div>

      {loading ? (
        <div className="flex justify-center py-20"><Loader2 className="animate-spin text-primary w-16 h-16" /></div>
      ) : !payouts || payouts.length === 0 ? (
        <Card className="cartoon-card p-20 text-center opacity-40">
           <Banknote className="w-20 h-20 mx-auto mb-6" />
           <p className="text-2xl font-black italic">ALL CLEAR! NO PENDING PAYOUTS.</p>
        </Card>
      ) : (
        <div className="grid gap-8">
          {payouts.map((payout: any) => (
            <Card key={payout.id} className="cartoon-card border-none bg-card/40 p-10 hover:scale-[1.02] transition-all">
              <div className="flex flex-col md:flex-row justify-between gap-8">
                <div className="space-y-6 flex-1">
                   <div className="flex items-center justify-between">
                      <div className="flex items-center gap-4">
                         <div className={cn(
                           "w-12 h-12 rounded-xl flex items-center justify-center border-2",
                           payout.userRole === 'COURIER' ? "bg-accent/20 border-accent/20 text-accent" : "bg-primary/20 border-primary/20 text-primary"
                         )}>
                            <User />
                         </div>
                         <div>
                            <p className="text-[10px] font-black uppercase opacity-40">{payout.userRole} Request</p>
                            <h4 className="text-2xl font-black italic uppercase">{payout.userName}</h4>
                         </div>
                      </div>
                      <Badge className="bg-primary/20 text-primary border-none px-4 py-1 font-black italic">PENDING</Badge>
                   </div>
                   
                   <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 p-6 bg-white/5 rounded-3xl border-2 border-white/5">
                      <div>
                         <p className="text-[10px] font-black uppercase opacity-40 mb-1">Target UPI ID</p>
                         <p className="text-2xl font-black text-accent tracking-tighter font-mono">{payout.upiId}</p>
                      </div>
                      <div>
                         <p className="text-[10px] font-black uppercase opacity-40 mb-1">Amount to Pay</p>
                         <p className="text-4xl font-black text-white italic">₹{payout.amount}</p>
                      </div>
                   </div>
                </div>

                <div className="flex flex-row md:flex-col gap-4 justify-center">
                  <Button 
                    variant="destructive" 
                    className="h-16 px-8 rounded-2xl font-black italic border-b-8 active:translate-y-1"
                    onClick={() => handleAction(payout, false)}
                  >
                    <XCircle className="mr-2" /> REJECT
                  </Button>
                  <Button 
                    className="h-16 px-8 rounded-2xl bg-green-500 hover:bg-green-600 font-black italic border-b-8 border-green-800 active:translate-y-1"
                    onClick={() => handleAction(payout, true)}
                  >
                    <CheckCircle className="mr-2" /> MARK AS PAID
                  </Button>
                </div>
              </div>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
