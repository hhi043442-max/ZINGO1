
"use client"

import React from 'react';
import { Card, CardHeader, CardContent, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { 
  Wallet, 
  ArrowUpRight, 
  ArrowDownLeft, 
  TrendingUp, 
  History,
  Download,
  ArrowLeft,
  DollarSign,
  PieChart
} from 'lucide-react';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer 
} from 'recharts';
import Link from 'next/link';

const transactionHistory = [
  { id: 1, type: 'CREDIT', amount: 450, note: 'Shop Commission: Deli Dairy', time: '2h ago' },
  { id: 2, type: 'DEBIT', amount: 1200, note: 'Withdrawal: Root Admin', time: '5h ago' },
  { id: 3, type: 'CREDIT', amount: 8, note: 'Courier Penalty: Order #ZNG-45', time: '1d ago' },
  { id: 4, type: 'CREDIT', amount: 10, note: 'Renewal: Fresh Mart', time: '1d ago' },
];

const data = [
  { name: 'Mon', rev: 4000 },
  { name: 'Tue', rev: 3000 },
  { name: 'Wed', rev: 2000 },
  { name: 'Thu', rev: 2780 },
  { name: 'Fri', rev: 1890 },
  { name: 'Sat', rev: 2390 },
  { name: 'Sun', rev: 3490 },
];

export default function AdminWallet() {
  return (
    <div className="min-h-screen bg-background p-6 md:p-12">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-6 mb-12">
        <div className="flex items-center gap-4">
          <Link href="/admin/dashboard">
            <Button variant="ghost" size="icon" className="rounded-full">
              <ArrowLeft className="w-6 h-6" />
            </Button>
          </Link>
          <div>
            <h1 className="text-4xl font-black">Global Wallet</h1>
            <p className="text-muted-foreground mt-1">Platform-wide financial oversight and audits</p>
          </div>
        </div>
        <Button className="h-12 font-bold px-8">
          <Download className="w-4 h-4 mr-2" /> Export Audit
        </Button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-12">
        {/* Main Balance Card */}
        <Card className="lg:col-span-2 gradient-bg border-none shadow-2xl p-8 relative overflow-hidden">
          <div className="relative z-10 flex flex-col h-full justify-between min-h-[250px]">
            <div>
              <p className="text-indigo-100/60 uppercase font-black tracking-widest text-xs mb-2">Total Platform Equity</p>
              <h2 className="text-6xl font-black text-white">₹1,42,850.45</h2>
            </div>
            <div className="flex gap-4">
              <Button size="lg" className="bg-white text-primary font-bold hover:bg-white/90">
                <ArrowDownLeft className="mr-2 w-5 h-5" /> Withdraw Capital
              </Button>
              <Button size="lg" variant="outline" className="border-white/20 text-white hover:bg-white/10">
                <History className="mr-2 w-5 h-5" /> Settlement Log
              </Button>
            </div>
          </div>
          <Wallet className="absolute -right-12 -bottom-12 w-64 h-64 text-white/5 rotate-12" />
        </Card>

        {/* Secondary Stats */}
        <div className="grid grid-cols-1 gap-4">
           <Card className="glass border-white/5 p-6 flex items-center gap-6">
              <div className="w-12 h-12 rounded-2xl bg-green-500/10 flex items-center justify-center">
                 <ArrowUpRight className="text-green-500 w-6 h-6" />
              </div>
              <div>
                 <p className="text-xs text-muted-foreground font-bold">24h Inflow</p>
                 <p className="text-2xl font-black text-green-500">+₹12,450</p>
              </div>
           </Card>
           <Card className="glass border-white/5 p-6 flex items-center gap-6">
              <div className="w-12 h-12 rounded-2xl bg-destructive/10 flex items-center justify-center">
                 <ArrowDownLeft className="text-destructive w-6 h-6" />
              </div>
              <div>
                 <p className="text-xs text-muted-foreground font-bold">24h Outflow</p>
                 <p className="text-2xl font-black text-destructive">-₹4,200</p>
              </div>
           </Card>
           <Card className="glass border-white/5 p-6 flex items-center gap-6">
              <div className="w-12 h-12 rounded-2xl bg-primary/10 flex items-center justify-center">
                 <DollarSign className="text-primary w-6 h-6" />
              </div>
              <div>
                 <p className="text-xs text-muted-foreground font-bold">Net Margin</p>
                 <p className="text-2xl font-black text-primary">12.5%</p>
              </div>
           </Card>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Revenue Chart */}
        <Card className="glass border-white/5 p-6">
          <CardHeader className="p-0 mb-8">
             <CardTitle>Revenue Stream</CardTitle>
             <CardDescription>Daily gross inflow across all channels</CardDescription>
          </CardHeader>
          <div className="h-[300px]">
            <ResponsiveContainer width="100%" height="100%">
               <BarChart data={data}>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#1f2937" />
                  <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{fill: '#9ca3af', fontSize: 12}} />
                  <YAxis axisLine={false} tickLine={false} tick={{fill: '#9ca3af', fontSize: 12}} />
                  <Tooltip cursor={{fill: 'rgba(122, 99, 255, 0.1)'}} contentStyle={{backgroundColor: '#0f0c19', border: '1px solid #7a63ff'}} />
                  <Bar dataKey="rev" fill="#7a63ff" radius={[6, 6, 0, 0]} />
               </BarChart>
            </ResponsiveContainer>
          </div>
        </Card>

        {/* Audit Trail */}
        <Card className="glass border-white/5">
          <CardHeader>
            <CardTitle>Global Audit Trail</CardTitle>
            <CardDescription>Real-time transaction monitoring</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {transactionHistory.map((tx) => (
              <div key={tx.id} className="flex items-center justify-between p-4 rounded-xl hover:bg-white/5 transition-colors border border-white/5">
                <div className="flex items-center gap-4">
                  <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${tx.type === 'CREDIT' ? 'bg-green-500/10 text-green-500' : 'bg-destructive/10 text-destructive'}`}>
                    {tx.type === 'CREDIT' ? <ArrowUpRight className="w-5 h-5" /> : <ArrowDownLeft className="w-5 h-5" />}
                  </div>
                  <div>
                    <p className="font-bold text-sm">{tx.note}</p>
                    <p className="text-[10px] text-muted-foreground uppercase">{tx.time}</p>
                  </div>
                </div>
                <p className={`font-black ${tx.type === 'CREDIT' ? 'text-green-500' : 'text-destructive'}`}>
                  {tx.type === 'CREDIT' ? '+' : '-'}₹{tx.amount}
                </p>
              </div>
            ))}
            <Button variant="link" className="w-full text-primary font-bold">View Full Ledger</Button>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
