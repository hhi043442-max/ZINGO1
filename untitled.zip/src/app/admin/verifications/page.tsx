
"use client"

import React from 'react';
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { CreditCard, CheckCircle, XCircle, ArrowLeft, Loader2, Banknote, User } from 'lucide-react';
import { useCollection, useFirestore } from '@/firebase';
import { collection, query, where, updateDoc, doc, increment } from 'firebase/firestore';
import { useToast } from '@/hooks/use-toast';
import Link from 'next/link';
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";

export default function AdminVerifications() {
  const db = useFirestore();
  const { toast } = useToast();

  const orderQuery = React.useMemo(() => {
    if (!db) return null;
    return query(collection(db, 'orders'), where('paymentStatus', '==', 'VERIFYING'));
  }, [db]);

  const settlementQuery = React.useMemo(() => {
    if (!db) return null;
    return query(collection(db, 'debt_settlements'), where('status', '==', 'PENDING'));
  }, [db]);

  const { data: orders, loading: orderLoading } = useCollection(orderQuery);
  const { data: settlements, loading: settleLoading } = useCollection(settlementQuery);

  const handleOrderAction = async (orderId: string, approve: boolean) => {
    if (!db) return;
    try {
      await updateDoc(doc(db, 'orders', orderId), { 
        paymentStatus: approve ? 'PAID' : 'PENDING',
        status: approve ? 'READY_FOR_PICKUP' : 'CANCELLED'
      });
      toast({ title: approve ? "Order Verified! ✅" : "Order Rejected ❌" });
    } catch (e: any) {
      console.error(e);
      toast({ variant: "destructive", title: "Action Failed", description: e.message });
    }
  };

  const handleSettleAction = async (settle: any, approve: boolean) => {
    if (!db) return;
    try {
      await updateDoc(doc(db, 'debt_settlements', settle.id), { 
        status: approve ? 'VERIFIED' : 'REJECTED'
      });
      
      if (approve) {
        // Reset the courier's debt
        await updateDoc(doc(db, 'users', settle.userId), {
          codCollected: 0,
          isBlocked: false
        });
      }
      
      toast({ title: approve ? "Debt Cleared! ✅" : "Settlement Rejected ❌" });
    } catch (e: any) {
      console.error(e);
      toast({ variant: "destructive", title: "Action Failed", description: e.message });
    }
  };

  return (
    <div className="min-h-screen bg-background p-6 md:p-12 font-body">
      <div className="flex items-center gap-6 mb-12">
        <Link href="/admin/dashboard">
          <Button variant="ghost" size="icon" className="w-14 h-14 rounded-2xl glass border-4">
            <ArrowLeft className="w-8 h-8" />
          </Button>
        </Link>
        <div>
          <h1 className="text-4xl font-black italic uppercase">The Verifier 🔎</h1>
          <p className="text-muted-foreground font-bold italic opacity-60">Check UTR IDs for Orders and Courier Debts</p>
        </div>
      </div>

      <Tabs defaultValue="orders" className="space-y-12">
        <TabsList className="bg-white/5 p-2 rounded-[2rem] h-20 grid grid-cols-2 max-w-2xl border-4 border-white/5">
           <TabsTrigger value="orders" className="rounded-2xl font-black italic text-xl data-[state=active]:bg-primary">
              <CreditCard className="mr-2" /> ORDERS
           </TabsTrigger>
           <TabsTrigger value="debt" className="rounded-2xl font-black italic text-xl data-[state=active]:bg-accent data-[state=active]:text-black">
              <Banknote className="mr-2" /> COURIER DEBTS
           </TabsTrigger>
        </TabsList>

        <TabsContent value="orders">
          {orderLoading ? (
            <div className="flex justify-center py-20"><Loader2 className="animate-spin text-primary w-16 h-16" /></div>
          ) : !orders || orders.length === 0 ? (
            <Card className="cartoon-card p-20 text-center opacity-40">
               <CheckCircle className="w-20 h-20 mx-auto mb-6" />
               <p className="text-2xl font-black italic">NO PENDING ORDERS.</p>
            </Card>
          ) : (
            <div className="grid gap-8">
              {orders.map((order: any) => (
                <Card key={order.id} className="cartoon-card border-none bg-card/40 p-10 hover:scale-[1.02] transition-all">
                  <div className="flex flex-col md:flex-row justify-between gap-8">
                    <div className="space-y-6 flex-1">
                       <div className="flex items-center gap-4">
                          <div className="w-12 h-12 bg-primary/20 rounded-xl flex items-center justify-center border-2 border-primary/20">
                             <CreditCard className="text-primary" />
                          </div>
                          <div>
                             <p className="text-[10px] font-black uppercase opacity-40">Payment For Order</p>
                             <h4 className="text-2xl font-black italic uppercase">#ZNG-{order.id.slice(-6).toUpperCase()}</h4>
                          </div>
                       </div>
                       
                       <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 p-6 bg-white/5 rounded-3xl border-2 border-white/5">
                          <div><p className="text-[10px] font-black uppercase opacity-40 mb-1">UTR ID</p><p className="text-3xl font-black text-accent tracking-widest font-mono">{order.transactionId}</p></div>
                          <div><p className="text-[10px] font-black uppercase opacity-40 mb-1">Amount</p><p className="text-3xl font-black text-white italic">₹{order.totalAmount}</p></div>
                       </div>
                       <p className="text-xs font-bold opacity-60">Customer: {order.customerName} ({order.customerPhone})</p>
                    </div>
                    <div className="flex flex-row md:flex-col gap-4 justify-center">
                      <Button variant="destructive" className="h-16 px-8 rounded-2xl font-black italic border-b-8 active:translate-y-1" onClick={() => handleOrderAction(order.id, false)}>REJECT</Button>
                      <Button className="h-16 px-8 rounded-2xl bg-green-500 hover:bg-green-600 font-black italic border-b-8 border-green-800 active:translate-y-1" onClick={() => handleOrderAction(order.id, true)}>APPROVE</Button>
                    </div>
                  </div>
                </Card>
              ))}
            </div>
          )}
        </TabsContent>

        <TabsContent value="debt">
          {settleLoading ? (
            <div className="flex justify-center py-20"><Loader2 className="animate-spin text-accent w-16 h-16" /></div>
          ) : !settlements || settlements.length === 0 ? (
            <Card className="cartoon-card border-accent/20 p-20 text-center opacity-40">
               <Banknote className="w-20 h-20 mx-auto mb-6" />
               <p className="text-2xl font-black italic text-accent">NO DEBT SETTLEMENTS PENDING.</p>
            </Card>
          ) : (
            <div className="grid gap-8">
              {settlements.map((settle: any) => (
                <Card key={settle.id} className="cartoon-card border-accent/20 bg-accent/5 p-10 hover:scale-[1.02] transition-all">
                  <div className="flex flex-col md:flex-row justify-between gap-8">
                    <div className="space-y-6 flex-1">
                       <div className="flex items-center gap-4">
                          <div className="w-12 h-12 bg-accent/20 rounded-xl flex items-center justify-center border-2 border-accent/20">
                             <User className="text-accent" />
                          </div>
                          <div>
                             <p className="text-[10px] font-black uppercase opacity-40">Debt Settlement For</p>
                             <h4 className="text-2xl font-black italic uppercase">{settle.userName}</h4>
                          </div>
                       </div>
                       
                       <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 p-6 bg-white/5 rounded-3xl border-2 border-white/5">
                          <div><p className="text-[10px] font-black uppercase opacity-40 mb-1">UTR ID</p><p className="text-3xl font-black text-primary tracking-widest font-mono">{settle.transactionId}</p></div>
                          <div><p className="text-[10px] font-black uppercase opacity-40 mb-1">Settling Amount</p><p className="text-3xl font-black text-white italic">₹{settle.amount}</p></div>
                       </div>
                    </div>
                    <div className="flex flex-row md:flex-col gap-4 justify-center">
                      <Button variant="destructive" className="h-16 px-8 rounded-2xl font-black italic border-b-8 active:translate-y-1" onClick={() => handleSettleAction(settle, false)}>REJECT</Button>
                      <Button className="h-16 px-8 rounded-2xl bg-accent text-black hover:bg-accent/90 font-black italic border-b-8 border-accent-foreground/20 active:translate-y-1" onClick={() => handleSettleAction(settle, true)}>CLEAR DEBT</Button>
                    </div>
                  </div>
                </Card>
              ))}
            </div>
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
}
