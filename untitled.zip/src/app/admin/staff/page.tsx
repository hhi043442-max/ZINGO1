
"use client"

import React, { useState } from 'react';
import { Card, CardHeader, CardContent, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { 
  Users, 
  UserPlus, 
  Search, 
  ShieldAlert, 
  Mail, 
  Phone,
  ArrowLeft,
  Loader2,
  Trash2,
  Crown
} from 'lucide-react';
import { useCollection, useFirestore, useFirebaseApp } from '@/firebase';
import { collection, query, where, deleteDoc, doc } from 'firebase/firestore';
import Link from 'next/link';
import { useToast } from '@/hooks/use-toast';

// Mock staff for prototype
const MOCK_STAFF = [
  { id: 's1', displayName: 'Naveen Baran', email: 'naveen@zingo.com', role: 'SUPER_ADMIN', phone: '+91 9876543210' },
  { id: 's2', displayName: 'Admin Support', email: 'support@zingo.com', role: 'STAFF', phone: '+91 0000011111' },
];

export default function StaffManagement() {
  const db = useFirestore();
  const app = useFirebaseApp();
  const { toast } = useToast();
  const [searchQuery, setSearchQuery] = useState('');
  
  const isPrototype = app?.name === '[PROTOTYPE_MODE]';

  const staffQuery = React.useMemo(() => {
    if (!db || isPrototype) return null;
    return query(collection(db, 'users'), where('role', 'in', ['STAFF', 'SUPER_ADMIN']));
  }, [db, isPrototype]);

  const { data: realStaff, loading: realLoading } = useCollection(staffQuery);

  const staffMembers = isPrototype ? MOCK_STAFF : realStaff;
  const loading = isPrototype ? false : realLoading;

  const handleDeleteStaff = async (id: string) => {
    if (isPrototype) {
      toast({ title: "DEMO ACTION", description: "Staff removal is disabled in Prototype mode." });
      return;
    }
    if (!db) return;
    try {
      await deleteDoc(doc(db, 'users', id));
      toast({ title: "Staff Member Removed" });
    } catch (error: any) {
      console.error(error);
      toast({ variant: "destructive", title: "Error", description: error.message });
    }
  };

  const filteredStaff = staffMembers?.filter(member => 
    member.displayName?.toLowerCase().includes(searchQuery.toLowerCase()) ||
    member.email?.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="min-h-screen bg-background p-6 md:p-12">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-8 mb-12">
        <div className="flex items-center gap-6">
          <Link href="/admin/dashboard">
            <Button variant="ghost" size="icon" className="w-14 h-14 rounded-2xl glass border-4">
              <ArrowLeft className="w-8 h-8" />
            </Button>
          </Link>
          <div>
            <h1 className="text-4xl md:text-5xl font-black italic">The Command Room</h1>
            <p className="text-muted-foreground font-bold italic opacity-60">Manage the legends running the Zingo show</p>
          </div>
        </div>
        <Button className="h-16 rounded-2xl font-black px-10 shadow-xl shadow-primary/20 text-xl italic border-b-8 border-primary-foreground/20">
          <UserPlus className="w-6 h-6 mr-3" /> INVITE HERO
        </Button>
      </div>

      <div className="grid grid-cols-1 gap-10">
        {/* Search and Filters */}
        <Card className="cartoon-card p-6">
          <div className="relative">
            <Search className="absolute left-6 top-1/2 -translate-y-1/2 text-muted-foreground w-6 h-6" />
            <Input 
              placeholder="Locate a legend..." 
              className="pl-16 h-16 bg-white/5 border-4 border-white/10 rounded-[1.5rem] font-black italic text-xl"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
        </Card>

        {isPrototype && (
          <div className="p-4 bg-primary/10 border-4 border-dashed border-primary rounded-[2rem] text-primary font-black text-center italic">
            PROTOTYPE DATA: SHARING COMMAND WITH DUMMY STAFF
          </div>
        )}

        {/* Staff List */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-10">
          {loading ? (
            <div className="col-span-full flex justify-center py-20">
              <Loader2 className="animate-spin text-primary w-20 h-20" />
            </div>
          ) : !filteredStaff || filteredStaff.length === 0 ? (
            <Card className="col-span-full cartoon-card p-20 text-center opacity-50">
              <Users className="w-20 h-20 mx-auto mb-6" />
              <p className="text-2xl font-black italic">NO SQUAD MEMBERS FOUND.</p>
            </Card>
          ) : (
            filteredStaff.map((member: any) => (
              <Card key={member.id} className="cartoon-card hover:translate-x-4 transition-all group overflow-hidden">
                <CardContent className="p-8">
                  <div className="flex justify-between items-start mb-8">
                    <div className="flex items-center gap-6">
                      <div className="w-20 h-20 rounded-[1.5rem] bg-primary/10 flex items-center justify-center border-4 border-primary/20 transform rotate-3 group-hover:rotate-0 transition-transform">
                        {member.role === 'SUPER_ADMIN' ? <Crown className="w-10 h-10 text-primary" /> : <Users className="w-10 h-10 text-primary" />}
                      </div>
                      <div>
                        <h4 className="text-3xl font-black italic">{member.displayName || 'Unnamed Staff'}</h4>
                        <Badge className="mt-2 bg-primary/20 text-primary border-none font-black px-4 py-1 italic">
                          {member.role}
                        </Badge>
                      </div>
                    </div>
                    <Button 
                      variant="ghost" 
                      size="icon" 
                      className="w-12 h-12 rounded-xl text-destructive/50 hover:text-destructive hover:bg-destructive/10 border-2 border-transparent hover:border-destructive/20"
                      onClick={() => handleDeleteStaff(member.id)}
                    >
                      <Trash2 className="w-6 h-6" />
                    </Button>
                  </div>

                  <div className="space-y-4">
                    <div className="flex items-center gap-4 text-lg font-bold italic opacity-60">
                      <Mail className="w-6 h-6 text-primary" />
                      <span>{member.email}</span>
                    </div>
                    <div className="flex items-center gap-4 text-lg font-bold italic opacity-60">
                      <Phone className="w-6 h-6 text-primary" />
                      <span>{member.phone || 'No direct frequency'}</span>
                    </div>
                  </div>

                  <div className="mt-8 pt-8 border-t-4 border-white/5 flex gap-4">
                    <Button variant="outline" className="flex-1 h-14 rounded-2xl font-black italic border-4">
                      RESET KEYS
                    </Button>
                    <Button variant="outline" className="flex-1 h-14 rounded-2xl font-black italic border-4">
                      UPGRADE ROLE
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))
          )}
        </div>
      </div>
    </div>
  );
}
