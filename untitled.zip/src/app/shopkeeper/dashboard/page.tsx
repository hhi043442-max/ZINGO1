
"use client"

import React, { useState, useEffect, useMemo } from 'react';
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { 
  ShoppingBag, 
  TrendingUp, 
  Users, 
  Wallet, 
  Clock, 
  Zap, 
  Power, 
  CheckCircle, 
  QrCode, 
  Download,
  Phone,
  MapPin,
  X,
  ShieldAlert,
  Loader2
} from 'lucide-react';
import { BottomNav } from '@/components/layout/bottom-nav';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { useUser, useDoc, useFirestore, useCollection } from '@/firebase';
import { doc, updateDoc, query, collection, where } from 'firebase/firestore';
import { cn } from '@/lib/utils';
import { useToast } from '@/hooks/use-toast';
import { Order } from '@/lib/types';

export default function ShopkeeperDashboard() {
  const { user } = useUser();
  const db = useFirestore();
  const { toast } = useToast();
  
  const [selectedOrder, setSelectedOrder] = useState<Order | null>(null);
  const [showQRModal, setShowQRModal] = useState(false);

  const userRef = useMemo(() => (user && db ? doc(db, 'users', user.uid) : null), [db, user]);
  const { data: userData, loading: userLoading } = useDoc(userRef);

  const ordersQuery = useMemo(() => {
    if (!db || !user?.uid) return null;
    return query(collection(db, 'orders'), where('shopId', '==', user.uid));
  }, [db, user?.uid]);

  const { data: orders, loading: ordersLoading } = useCollection(ordersQuery);

  if (userLoading) return <div className="min-h-screen flex items-center justify-center bg-background"><Loader2 className="animate-spin w-20 h-20 text-primary" /></div>;

  if (userData && !userData.isVerified) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center p-8 font-body">
        <Card className="cartoon-card max-w-md p-10 text-center space-y-8 bg-destructive/10 border-destructive">
          <div className="w-24 h-24 bg-destructive/20 rounded-[2rem] flex items-center justify-center mx-auto animate-pulse">
            <ShieldAlert className="text-destructive w-12 h-12" />
          </div>
          <div>
            <h2 className="text-4xl font-black italic text-destructive uppercase">Pending Activation!</h2>
            <p className="text-white/60 font-bold mt-4">
              Your activation request (UTR: <span className="text-white font-mono">{userData.activationUtr}</span>) is being reviewed by the Zingo HQ. 
            </p>
          </div>
          <p className="text-[10px] font-black uppercase tracking-widest opacity-40">Access will be granted within 24 hours.</p>
          <Button variant="outline" className="w-full h-14 rounded-2xl border-4" onClick={() => window.location.reload()}>RE-SCAN DATABASE 🔎</Button>
        </Card>
      </div>
    );
  }

  const handleToggleStore = async (checked: boolean) => {
    if (!userRef) return;
    try {
      await updateDoc(userRef, { isStoreOpen: checked });
      toast({ title: checked ? "STORE IS LIVE! 🚀" : "STORE OFFLINE 😴" });
    } catch (e) { console.error("Toggle store error:", e); }
  };

  const handleApproveOrder = async (orderId: string) => {
    if (!db) return;
    try {
      await updateDoc(doc(db, 'orders', orderId), { 
        status: 'READY_FOR_PICKUP' 
      });
      toast({ title: "MISSION APPROVED! ✅", description: "Courier can now pick up the loot." });
    } catch (e) { console.error("Approve order error:", e); }
  };

  const downloadQR = (orderId: string) => {
    const qrUrl = `https://api.qrserver.com/v1/create-qr-code/?size=500x500&data=zingo_order_${orderId}`;
    const link = document.createElement('a');
    link.href = qrUrl;
    link.download = `QR_Order_${orderId}.png`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    toast({ title: "QR DOWNLOADED! 📥" });
  };

  const pendingMissions = orders?.filter(o => o.status === 'PENDING_SHOP_APPROVAL') || [];
  const activeMissions = orders?.filter(o => o.status !== 'PENDING_SHOP_APPROVAL' && o.status !== 'DELIVERED') || [];

  return (
    <div className="min-h-screen bg-background pb-32 font-body overflow-x-hidden">
      <header className="p-8 gradient-bg rounded-b-[4rem] shadow-2xl relative overflow-hidden">
        <div className="relative z-10 flex flex-col sm:flex-row justify-between items-start gap-8 mb-10">
          <div>
            <h1 className="text-4xl font-black text-white italic tracking-tighter uppercase">MERCHANT HUB</h1>
            <p className="text-indigo-100/60 font-black italic uppercase text-[10px] tracking-[0.3em]">
              Welcome, {userData?.displayName || 'Legend'}
            </p>
          </div>
          
          <div className={cn(
            "flex items-center justify-between gap-6 px-6 py-4 rounded-[2rem] border-4 transition-all shadow-2xl",
            userData?.isStoreOpen ? "bg-green-500/20 border-green-400/50" : "bg-destructive/20 border-destructive/50"
          )}>
            <Power className={cn("w-6 h-6", userData?.isStoreOpen ? "text-green-400" : "text-destructive")} />
            <span className={cn("text-xl font-black italic uppercase", userData?.isStoreOpen ? "text-green-400" : "text-destructive")}>
              {userData?.isStoreOpen ? "ON AIR" : "OFFLINE"}
            </span>
            <Switch checked={userData?.isStoreOpen ?? true} onCheckedChange={handleToggleStore} className="scale-125" />
          </div>
        </div>

        <div className="grid grid-cols-2 gap-6 relative z-10">
          <StatCard label="Earnings" value={`₹${userData?.walletBalance || 0}`} icon={Wallet} color="text-primary" />
          <StatCard label="Missions" value={activeMissions.length.toString()} icon={ShoppingBag} color="text-accent" />
        </div>
      </header>

      <div className="p-8 space-y-10">
        <Section title="PENDING APPROVAL ⏳" orders={pendingMissions} type="PENDING" onApprove={handleApproveOrder} />
        <Section title="ACTIVE MISSIONS 🏃" orders={activeMissions} type="ACTIVE" onShowQR={(o) => { setSelectedOrder(o); setShowQRModal(true); }} />
      </div>

      <Dialog open={showQRModal} onOpenChange={setShowQRModal}>
        <DialogContent className="glass border-primary/20 sm:max-w-md rounded-[3rem] p-8 text-center">
          <DialogHeader className="sr-only">
            <DialogTitle>Mission Pass QR Code</DialogTitle>
          </DialogHeader>
          <h2 className="text-3xl font-black italic uppercase mb-6">MISSION PASS! 📦</h2>
          {selectedOrder && (
            <div className="flex flex-col items-center gap-6">
              <div className="bg-white p-4 rounded-[2rem] shadow-2xl">
                <img 
                  src={`https://api.qrserver.com/v1/create-qr-code/?size=250x250&data=zingo_order_${selectedOrder.id}`} 
                  alt="Order QR" 
                  className="w-48 h-48"
                />
              </div>
              <p className="font-black text-xs opacity-40 uppercase tracking-widest">ORDER ID: #ZNG-{selectedOrder.id.slice(-6).toUpperCase()}</p>
              <Button 
                onClick={() => downloadQR(selectedOrder.id)}
                className="w-full h-16 rounded-2xl bg-primary font-black italic text-xl border-b-8 border-indigo-200 active:translate-y-2"
              >
                <Download className="mr-2 w-6 h-6" /> DOWNLOAD QR
              </Button>
            </div>
          )}
        </DialogContent>
      </Dialog>

      <BottomNav role="SHOPKEEPER" />
    </div>
  );
}

function StatCard({ label, value, icon: Icon, color }: any) {
  return (
    <Card className="cartoon-card border-none bg-card/40 backdrop-blur-3xl">
      <CardContent className="p-6">
        <Icon className={cn("w-6 h-6 mb-4", color)} />
        <p className="text-[10px] text-muted-foreground uppercase font-black italic tracking-widest opacity-60">{label}</p>
        <p className="text-3xl font-black mt-1 text-white">{value}</p>
      </CardContent>
    </Card>
  );
}

function Section({ title, orders, type, onApprove, onShowQR }: any) {
  return (
    <div className="space-y-6">
      <h2 className="text-3xl font-black italic tracking-tighter uppercase">{title}</h2>
      {orders.length === 0 ? (
        <p className="text-center opacity-30 italic py-10">No missions found.</p>
      ) : (
        <div className="space-y-4">
          {orders.map((order: any) => (
            <Card key={order.id} className="cartoon-card border-none bg-card/40 p-6">
              <div className="flex justify-between items-start mb-4">
                <div>
                  <h4 className="font-black italic text-xl text-white">#ZNG-{order.id.slice(-6).toUpperCase()}</h4>
                  <p className="text-xs font-bold text-muted-foreground uppercase">{order.items[0]?.name} x{order.items[0]?.quantity}</p>
                </div>
                <div className="text-right">
                  <p className="font-black text-2xl text-primary">₹{order.totalAmount}</p>
                </div>
              </div>
              
              <div className="space-y-2 mb-6 pt-4 border-t border-white/5">
                <div className="flex items-center gap-2 text-xs font-bold text-indigo-100/60">
                   <Users className="w-4 h-4 text-primary" />
                   <span>{order.customerName}</span>
                </div>
                <div className="flex items-center gap-2 text-xs font-bold text-indigo-100/60">
                   <Phone className="w-4 h-4 text-primary" />
                   <span>{order.customerPhone}</span>
                </div>
                <div className="flex items-center gap-2 text-xs font-bold text-indigo-100/60">
                   <MapPin className="w-4 h-4 text-primary" />
                   <span className="truncate">{order.deliveryAddress}</span>
                </div>
              </div>

              {type === 'PENDING' ? (
                <Button onClick={() => onApprove(order.id)} className="w-full h-14 rounded-2xl bg-primary font-black italic border-b-4">
                  APPROVE MISSION ✅
                </Button>
              ) : (
                <div className="flex gap-2">
                  <Button onClick={() => onShowQR(order)} className="flex-1 h-14 rounded-2xl bg-accent font-black italic border-b-4 text-black">
                    <QrCode className="mr-2 w-5 h-5" /> SHOW QR
                  </Button>
                  <Button variant="ghost" className="h-14 rounded-2xl bg-white/5 border-2 border-white/5">
                    <X className="w-5 h-5" />
                  </Button>
                </div>
              )}
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
