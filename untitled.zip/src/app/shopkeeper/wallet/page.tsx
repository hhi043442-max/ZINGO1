
"use client"

import React, { useState, useMemo } from 'react';
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Wallet, ArrowUpRight, History, CreditCard, Clock, Loader2, DollarSign } from 'lucide-react';
import { BottomNav } from '@/components/layout/bottom-nav';
import { useDoc, useUser, useFirestore } from '@/firebase';
import { doc, addDoc, collection, serverTimestamp, updateDoc } from 'firebase/firestore';
import { useToast } from '@/hooks/use-toast';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { SHOPKEEPER_MIN_WITHDRAW } from '@/lib/types';

export default function ShopkeeperWallet() {
  const { user } = useUser();
  const db = useFirestore();
  const { toast } = useToast();
  
  const [showWithdraw, setShowWithdraw] = useState(false);
  const [withdrawAmount, setWithdrawAmount] = useState('');
  const [withdrawUpi, setWithdrawUpi] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  const userDocRef = useMemo(() => {
    if (!db || !user?.uid) return null;
    return doc(db, 'users', user.uid);
  }, [db, user?.uid]);

  const { data: userData } = useDoc(userDocRef);

  const handleWithdraw = async () => {
    const amount = Number(withdrawAmount);
    if (amount < SHOPKEEPER_MIN_WITHDRAW) {
      toast({ variant: "destructive", title: "Limit Too Low!", description: `Min withdraw is ₹${SHOPKEEPER_MIN_WITHDRAW}` });
      return;
    }
    if (amount > (userData?.walletBalance || 0)) {
      toast({ variant: "destructive", title: "Insufficient Funds!", description: "Check your vault again." });
      return;
    }
    if (!withdrawUpi) {
      toast({ variant: "destructive", title: "UPI ID Missing!" });
      return;
    }

    setIsSubmitting(true);
    try {
      await addDoc(collection(db!, 'payout_requests'), {
        userId: user!.uid,
        userName: userData!.displayName,
        userRole: 'SHOPKEEPER',
        amount: amount,
        upiId: withdrawUpi,
        status: 'PENDING',
        createdAt: serverTimestamp()
      });
      
      await updateDoc(userDocRef!, {
        walletBalance: (userData?.walletBalance || 0) - amount
      });

      toast({ title: "VAULT WITHDRAWAL REQUESTED! 🚀", description: "Admin will process your payment shortly." });
      setShowWithdraw(false);
    } catch (e: any) {
      console.error(e);
      toast({ variant: "destructive", title: "Request Failed", description: e.message });
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen bg-background pb-32 font-body">
      <header className="p-8 gradient-bg rounded-b-[4rem] text-white shadow-2xl">
        <h1 className="text-3xl font-black italic uppercase">Business Vault 🏦</h1>
        <p className="text-indigo-100/60 font-black uppercase text-[10px] tracking-widest mt-1">Manage your merchant earnings</p>
      </header>

      <div className="p-8 space-y-10">
        <Card className="cartoon-card border-none bg-card/40 p-10 text-center relative overflow-hidden">
            <div className="relative z-10">
              <p className="text-[10px] font-black uppercase opacity-40 italic tracking-widest">Business Balance</p>
              <h2 className="text-7xl font-black italic text-white my-6">₹{userData?.walletBalance || 0}</h2>
              <Button 
                onClick={() => setShowWithdraw(true)}
                className="w-full h-20 rounded-[2rem] bg-primary font-black italic text-2xl border-b-8 border-indigo-700 shadow-2xl active:translate-y-2 transition-all"
              >
                REQUEST PAYOUT! 🏦
              </Button>
            </div>
            <DollarSign className="absolute -left-12 -bottom-12 w-48 h-48 text-white/5 rotate-12" />
        </Card>

        <div className="space-y-6">
           <h3 className="text-2xl font-black italic flex items-center gap-3">
              <History className="text-primary" /> RECENT SETTLEMENTS
           </h3>
           <div className="space-y-4">
              {[1, 2].map(i => (
                <Card key={i} className="cartoon-card border-none bg-white/5 p-6 flex items-center justify-between">
                   <div className="flex items-center gap-4">
                      <div className="w-12 h-12 bg-green-500/10 rounded-2xl flex items-center justify-center">
                         <ArrowUpRight className="text-green-500 w-6 h-6" />
                      </div>
                      <div>
                         <p className="font-black italic text-white">Settlement #{i}452</p>
                         <p className="text-[10px] font-black opacity-30 uppercase">Completed • 2 Days Ago</p>
                      </div>
                   </div>
                   <p className="text-2xl font-black text-green-500 italic">₹1,200</p>
                </Card>
              ))}
           </div>
        </div>
      </div>

      <Dialog open={showWithdraw} onOpenChange={setShowWithdraw}>
         <DialogContent className="glass border-primary rounded-[3rem] p-8 max-w-md">
            <DialogHeader><DialogTitle className="text-3xl font-black italic uppercase text-center tracking-tighter">VAULT WITHDRAWAL 🏦</DialogTitle></DialogHeader>
            <div className="space-y-6 pt-6">
               <div className="space-y-2">
                  <Label className="font-black italic text-[10px] uppercase opacity-40 tracking-widest">Payout Amount (Min ₹{SHOPKEEPER_MIN_WITHDRAW})</Label>
                  <Input 
                    type="number" 
                    placeholder="0.00" 
                    className="h-16 bg-white/5 border-4 rounded-2xl font-black text-3xl text-center" 
                    value={withdrawAmount}
                    onChange={(e) => setWithdrawAmount(e.target.value)}
                  />
               </div>
               <div className="space-y-2">
                  <Label className="font-black italic text-[10px] uppercase opacity-40 tracking-widest">Business UPI ID</Label>
                  <Input 
                    placeholder="merchant@upi" 
                    className="h-16 bg-white/5 border-4 rounded-2xl font-black text-xl text-center" 
                    value={withdrawUpi}
                    onChange={(e) => setWithdrawUpi(e.target.value)}
                  />
               </div>
               <Button 
                 onClick={handleWithdraw}
                 disabled={isSubmitting}
                 className="w-full h-20 rounded-[2rem] bg-primary font-black italic text-2xl border-b-8 shadow-2xl active:translate-y-2"
               >
                 {isSubmitting ? <Loader2 className="animate-spin" /> : "RELEASE FUNDS! 🚀"}
               </Button>
            </div>
         </DialogContent>
      </Dialog>

      <BottomNav role="SHOPKEEPER" />
    </div>
  );
}
