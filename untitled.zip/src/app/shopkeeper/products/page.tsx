
"use client"

import React, { useState, useRef } from 'react';
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Plus, Package, Edit, Trash2, Loader2, ImagePlus, X, Check } from 'lucide-react';
import { BottomNav } from '@/components/layout/bottom-nav';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { useCollection, useUser, useFirestore } from '@/firebase';
import { collection, addDoc, deleteDoc, doc, query, where, serverTimestamp } from 'firebase/firestore';
import { useToast } from '@/hooks/use-toast';
import { cn } from '@/lib/utils';

export default function ShopkeeperProducts() {
  const { user } = useUser();
  const db = useFirestore();
  const { toast } = useToast();
  const [isAdding, setIsAdding] = useState(false);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const [selectedSizes, setSelectedSizes] = useState<string[]>([]);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const availableSizes = ['S', 'M', 'L', 'XL', 'XXL', 'Universal', '1kg', '500g', '250g'];

  const productsQuery = React.useMemo(() => {
    if (!db || !user?.uid) return null;
    return query(collection(db, 'products'), where('shopId', '==', user.uid));
  }, [db, user?.uid]);

  const { data: products, loading } = useCollection(productsQuery);

  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 2 * 1024 * 1024) {
        toast({ variant: "destructive", title: "File too large!", description: "Please select an image smaller than 2MB." });
        return;
      }
      const reader = new FileReader();
      reader.onloadend = () => setImagePreview(reader.result as string);
      reader.readAsDataURL(file);
    }
  };

  const toggleSize = (size: string) => {
    setSelectedSizes(prev => 
      prev.includes(size) ? prev.filter(s => s !== size) : [...prev, size]
    );
  };

  const handleAddProduct = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    if (!db || !user?.uid) return;

    setIsAdding(true);
    const formData = new FormData(e.currentTarget);
    
    try {
      await addDoc(collection(db, 'products'), {
        name: formData.get('name'),
        basePrice: Number(formData.get('price')),
        description: formData.get('description'),
        category: formData.get('category'),
        quantity: Number(formData.get('quantity')),
        sizes: selectedSizes,
        shopId: user.uid,
        imageUrl: imagePreview || `https://picsum.photos/seed/${Math.random()}/400/300`,
        createdAt: serverTimestamp()
      });
      
      toast({ title: "Product Live! 🚀", description: "Your new loot is now visible to customers." });
      setIsDialogOpen(false);
      setImagePreview(null);
      setSelectedSizes([]);
    } catch (error: any) {
      console.error(error);
      toast({ variant: "destructive", title: "Upload Failed ❌", description: error.message });
    } finally {
      setIsAdding(false);
    }
  };

  const handleDelete = async (id: string) => {
    if (!db) return;
    try {
      await deleteDoc(doc(db, 'products', id));
      toast({ title: "Product Vaporized! 💨" });
    } catch (error: any) {
      console.error(error);
      toast({ variant: "destructive", title: "Error", description: error.message });
    }
  };

  return (
    <div className="min-h-screen bg-background pb-32 font-body">
      <header className="p-8 gradient-bg rounded-b-[4rem] shadow-2xl relative overflow-hidden">
        <div className="relative z-10 flex justify-between items-center text-white">
          <div>
            <h1 className="text-4xl font-black italic tracking-tighter">THE ARMORY</h1>
            <p className="text-indigo-100/60 font-black italic uppercase text-[10px] tracking-widest mt-1">Manage Your Inventory</p>
          </div>
          
          <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
            <DialogTrigger asChild>
              <Button className="h-16 w-16 rounded-[1.5rem] bg-white text-primary hover:bg-white/90 shadow-2xl border-b-8 border-indigo-200 active:border-b-0 active:translate-y-2 transition-all">
                <Plus className="w-8 h-8" />
              </Button>
            </DialogTrigger>
            <DialogContent className="glass border-white/10 sm:max-w-lg rounded-[3rem] p-0 overflow-y-auto max-h-[90vh] no-scrollbar">
              <div className="p-8 bg-primary/10 border-b-4 border-white/5">
                <DialogTitle className="text-3xl font-black italic tracking-tighter text-white uppercase">ADD NEW LOOT 📦</DialogTitle>
              </div>
              <form onSubmit={handleAddProduct} className="p-8 space-y-6">
                <div className="space-y-3">
                  <Label className="font-black text-[10px] uppercase tracking-widest opacity-40 italic">Product Visual</Label>
                  <div 
                    onClick={() => fileInputRef.current?.click()}
                    className="relative h-48 w-full border-4 border-dashed border-white/10 rounded-[2rem] flex flex-col items-center justify-center cursor-pointer hover:bg-white/5 transition-all overflow-hidden group"
                  >
                    {imagePreview ? (
                      <>
                        <img src={imagePreview} className="w-full h-full object-cover" alt="Preview" />
                        <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 flex items-center justify-center transition-opacity">
                          <Edit className="text-white w-10 h-10" />
                        </div>
                      </>
                    ) : (
                      <>
                        <ImagePlus className="w-12 h-12 text-primary/40 mb-2 group-hover:scale-110 transition-transform" />
                        <p className="text-xs font-black italic opacity-40 uppercase tracking-widest">Select From Gallery</p>
                      </>
                    )}
                    <input type="file" ref={fileInputRef} className="hidden" accept="image/*" onChange={handleImageChange} />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-3">
                    <Label className="font-black text-[10px] uppercase tracking-widest opacity-40 italic">Product Name</Label>
                    <Input name="name" placeholder="Name" className="h-14 bg-white/5 border-4 border-white/10 rounded-2xl font-bold" required />
                  </div>
                  <div className="space-y-3">
                    <Label className="font-black text-[10px] uppercase tracking-widest opacity-40 italic">Initial Stock (Qty)</Label>
                    <Input name="quantity" type="number" placeholder="0" className="h-14 bg-white/5 border-4 border-white/10 rounded-2xl font-bold" required />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                   <div className="space-y-3">
                    <Label className="font-black text-[10px] uppercase tracking-widest opacity-40 italic">Price (₹)</Label>
                    <Input name="price" type="number" placeholder="0" className="h-14 bg-white/5 border-4 border-white/10 rounded-2xl font-bold" required />
                  </div>
                  <div className="space-y-3">
                    <Label className="font-black text-[10px] uppercase tracking-widest opacity-40 italic">Category</Label>
                    <Input name="category" placeholder="Loot" className="h-14 bg-white/5 border-4 border-white/10 rounded-2xl font-bold" />
                  </div>
                </div>

                <div className="space-y-3">
                  <Label className="font-black text-[10px] uppercase tracking-widest opacity-40 italic">Available Sizes</Label>
                  <div className="flex flex-wrap gap-2">
                    {availableSizes.map(size => (
                      <button
                        key={size}
                        type="button"
                        onClick={() => toggleSize(size)}
                        className={cn(
                          "px-4 py-2 rounded-xl text-xs font-black italic border-2 transition-all active:scale-90",
                          selectedSizes.includes(size) 
                            ? "bg-primary text-white border-white" 
                            : "bg-white/5 border-white/10 text-muted-foreground"
                        )}
                      >
                        {size}
                      </button>
                    ))}
                  </div>
                </div>

                <div className="space-y-3">
                  <Label className="font-black text-[10px] uppercase tracking-widest opacity-40 italic">Description</Label>
                  <Textarea name="description" placeholder="Item intelligence..." className="bg-white/5 border-4 border-white/10 rounded-2xl font-bold min-h-[100px]" />
                </div>

                <Button type="submit" className="w-full h-20 text-2xl font-black italic rounded-[2rem] bg-primary border-b-8 border-primary-foreground/20 active:translate-y-2 active:border-b-0 shadow-2xl" disabled={isAdding}>
                  {isAdding ? <Loader2 className="animate-spin" /> : "PUBLISH ITEM! 🚀"}
                </Button>
              </form>
            </DialogContent>
          </Dialog>
        </div>
        <Package className="absolute -right-12 -bottom-12 w-48 h-48 text-white/5 rotate-12 pointer-events-none" />
      </header>

      <div className="p-8 space-y-6">
        {loading ? (
          <div className="flex flex-col items-center justify-center py-20 gap-4">
            <Loader2 className="animate-spin text-primary w-12 h-12" />
            <p className="font-black italic text-primary uppercase tracking-widest text-xs">Scanning Vault...</p>
          </div>
        ) : products?.length === 0 ? (
          <div className="text-center py-20 opacity-30 flex flex-col items-center gap-6">
             <div className="w-32 h-32 bg-white/5 rounded-[3rem] flex items-center justify-center border-4 border-white/5 text-white">
                <Package className="w-16 h-16" />
             </div>
             <p className="text-2xl font-black italic uppercase text-white">VAULT IS EMPTY!</p>
          </div>
        ) : (
          <div className="grid gap-6">
            {products?.map((p: any) => (
              <Card key={p.id} className="cartoon-card border-none bg-card/40 overflow-hidden group">
                <CardContent className="p-0 flex flex-col sm:flex-row items-stretch">
                  <div className="w-full sm:w-32 h-48 sm:h-auto relative overflow-hidden">
                    <img src={p.imageUrl} alt={p.name} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500" />
                  </div>
                  <div className="flex-1 p-6 flex flex-col justify-between">
                    <div>
                      <div className="flex justify-between items-start">
                        <h4 className="font-black italic text-2xl text-white uppercase tracking-tighter">{p.name}</h4>
                        <Button 
                          size="icon" 
                          variant="ghost" 
                          className="h-10 w-10 rounded-xl bg-destructive/10 text-destructive/50 hover:text-destructive hover:bg-destructive/20 transition-all"
                          onClick={() => handleDelete(p.id)}
                        >
                          <Trash2 className="w-5 h-5" />
                        </Button>
                      </div>
                      <div className="flex flex-wrap gap-1 mt-2">
                        {p.sizes?.map((s: string) => (
                          <span key={s} className="text-[8px] font-black bg-white/5 border border-white/10 px-2 py-0.5 rounded-full text-white italic">{s}</span>
                        ))}
                      </div>
                    </div>
                    <div className="mt-4 flex justify-between items-end">
                       <div>
                          <p className="text-[8px] font-black opacity-30 uppercase italic">Stock: {p.quantity || 0}</p>
                          <p className="font-black text-3xl text-primary italic tracking-tighter leading-none">₹{p.basePrice}</p>
                       </div>
                       <div className="bg-primary/10 px-3 py-1 rounded-full border border-primary/20">
                          <span className="text-[10px] font-black text-primary italic uppercase">{p.category || 'General'}</span>
                       </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>

      <BottomNav role="SHOPKEEPER" />
    </div>
  );
}
