
"use client"

import React from 'react';
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { User, LogOut, Settings, Shield, Bell, HelpCircle } from 'lucide-react';
import { BottomNav } from '@/components/layout/bottom-nav';
import { useUser, useAuth } from '@/firebase';
import { signOut } from 'firebase/auth';
import { useRouter } from 'next/navigation';

export default function CustomerProfile() {
  const { user } = useUser();
  const auth = useAuth();
  const router = useRouter();

  const handleLogout = async () => {
    await signOut(auth);
    router.push('/login');
  };

  return (
    <div className="min-h-screen bg-background pb-20">
      <header className="p-12 gradient-bg rounded-b-[4rem] text-center">
        <div className="w-24 h-24 bg-white/20 backdrop-blur-md rounded-full mx-auto mb-4 flex items-center justify-center border-4 border-white/10">
          <User className="w-12 h-12 text-white" />
        </div>
        <h1 className="text-2xl font-black text-white">{user?.displayName || 'User'}</h1>
        <p className="text-indigo-100/60 text-sm">{user?.email}</p>
      </header>

      <div className="p-6 -mt-8 space-y-4">
        <Card className="glass border-none shadow-xl">
          <CardContent className="p-2">
            <ProfileItem icon={Settings} label="Account Settings" />
            <ProfileItem icon={Bell} label="Notifications" />
            <ProfileItem icon={Shield} label="Privacy & Security" />
            <ProfileItem icon={HelpCircle} label="Help & Support" />
          </CardContent>
        </Card>

        <Button 
          variant="destructive" 
          className="w-full h-12 font-bold rounded-2xl"
          onClick={handleLogout}
        >
          <LogOut className="w-4 h-4 mr-2" /> Log Out
        </Button>
      </div>

      <BottomNav role="CUSTOMER" />
    </div>
  );
}

function ProfileItem({ icon: Icon, label }: any) {
  return (
    <button className="w-full flex items-center gap-4 p-4 hover:bg-white/5 rounded-2xl transition-colors">
      <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center">
        <Icon className="w-5 h-5 text-primary" />
      </div>
      <span className="font-semibold flex-1 text-left">{label}</span>
      <Settings className="w-4 h-4 text-muted-foreground opacity-20" />
    </button>
  );
}
