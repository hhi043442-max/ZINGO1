
"use client"

import React, { useState, useMemo } from 'react';
import { BottomNav } from '@/components/layout/bottom-nav';
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Search, ShoppingBag, Bell, SlidersHorizontal, MapPin, Star, Sparkles, TrendingUp } from 'lucide-react';
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import Link from 'next/link';
import { useCollection, useFirestore } from '@/firebase';
import { collection, query } from 'firebase/firestore';
import { PlaceHolderImages } from '@/lib/placeholder-images';
import { cn } from '@/lib/utils';

export default function CustomerHome() {
  const [activeCategory, setActiveCategory] = useState('All');
  const db = useFirestore();

  const productsQuery = useMemo(() => {
    if (!db) return null;
    return query(collection(db, 'products'));
  }, [db]);

  const { data: realProducts, loading } = useCollection(productsQuery);

  const categories = ['All', 'Groceries', 'Fruits', 'Dairy', 'Snacks', 'Personal Care'];

  // Mock products if DB is empty for visual testing
  const mockItems = [
    { id: '1', name: 'Alphonso Mango', basePrice: 450, shopId: 'm1', imageUrl: PlaceHolderImages.find(i => i.id === 'mango')?.imageUrl, category: 'Fruits' },
    { id: '2', name: 'Amul Butter', basePrice: 58, shopId: 'm2', imageUrl: PlaceHolderImages.find(i => i.id === 'butter')?.imageUrl, category: 'Dairy' },
  ];

  const items = realProducts && realProducts.length > 0 ? realProducts : mockItems;

  return (
    <div className="min-h-screen bg-background pb-32 font-body overflow-x-hidden">
      {/* Dynamic Header */}
      <header className="p-8 pb-4 space-y-8">
        <div className="flex justify-between items-start">
          <div className="flex items-center gap-4 bg-white/5 p-4 rounded-[2rem] border-4 border-white/10 shadow-2xl">
            <div className="w-12 h-12 bg-primary rounded-2xl flex items-center justify-center shadow-lg transform -rotate-12 border-2 border-white">
               <MapPin className="text-white w-6 h-6 animate-bounce" />
            </div>
            <div>
              <p className="text-[10px] text-muted-foreground uppercase font-black tracking-[0.3em] italic">Delivering To</p>
              <p className="text-lg font-black italic truncate max-w-[140px] text-white">The Secret Bunker 🚀</p>
            </div>
          </div>
          <div className="flex gap-4">
            <Button size="icon" variant="secondary" className="rounded-[1.5rem] h-16 w-16 glass border-4 border-white/10 relative shadow-2xl group active:scale-90 transition-all">
              <Bell className="w-8 h-8 group-hover:rotate-12 transition-transform" />
              <span className="absolute top-3 right-3 w-5 h-5 bg-primary rounded-full border-4 border-background animate-pulse"></span>
            </Button>
            <Link href="/customer/orders">
              <Button size="icon" variant="secondary" className="rounded-[1.5rem] h-16 w-16 glass border-4 border-white/10 shadow-2xl group active:scale-90 transition-all">
                <ShoppingBag className="w-8 h-8 group-hover:-translate-y-1 transition-transform" />
              </Button>
            </Link>
          </div>
        </div>

        <div className="relative group">
          <Search className="absolute left-6 top-1/2 -translate-y-1/2 text-muted-foreground w-8 h-8 group-focus-within:text-primary transition-colors" />
          <Input 
            className="pl-16 h-20 bg-white/5 border-4 border-white/10 rounded-[2.5rem] focus:border-primary text-xl font-black italic text-white placeholder:text-muted-foreground/30 shadow-inner" 
            placeholder="Search the kingdom..." 
          />
          <Button size="icon" variant="ghost" className="absolute right-4 top-1/2 -translate-y-1/2 w-14 h-14 bg-primary/10 rounded-2xl border-2 border-primary/20">
            <SlidersHorizontal className="w-7 h-7 text-primary" />
          </Button>
        </div>
      </header>

      {/* Trending Categories */}
      <div className="px-4">
        <div className="flex gap-4 overflow-x-auto p-4 scrollbar-hide no-scrollbar">
          {categories.map(cat => (
            <Button 
              key={cat}
              variant={activeCategory === cat ? 'default' : 'secondary'}
              className={cn(
                "rounded-[2rem] h-16 whitespace-nowrap px-10 font-black italic border-b-8 transition-all active:translate-y-2 active:border-b-0",
                activeCategory === cat 
                  ? "bg-primary border-primary-foreground/20 shadow-[0_10px_20px_rgba(122,99,255,0.4)]" 
                  : "bg-white/5 border-white/10 text-muted-foreground"
              )}
              onClick={() => setActiveCategory(cat)}
            >
              {cat}
            </Button>
          ))}
        </div>
      </div>

      {/* Hero Banner */}
      <div className="px-8 my-8">
        <div className="h-56 gradient-bg rounded-[4rem] p-10 flex items-center justify-between relative overflow-hidden group border-8 border-white/10 shadow-2xl">
          <div className="relative z-10 text-white max-w-[280px]">
            <div className="flex items-center gap-2 mb-4">
               <Sparkles className="text-accent w-6 h-6 animate-pulse" />
               <span className="text-[10px] font-black uppercase tracking-[0.4em] italic text-accent">Limited Offer</span>
            </div>
            <h3 className="text-5xl font-black mb-4 italic leading-none tracking-tighter">FREE<br/>LOOT! 📦</h3>
            <p className="text-sm font-bold opacity-80 uppercase tracking-widest italic leading-tight">Zero delivery fees on your next 3 missions!</p>
            <Button size="lg" className="mt-6 bg-white text-primary font-black rounded-full px-10 hover:scale-110 active:scale-95 transition-all shadow-xl italic text-lg">CLAIM NOW</Button>
          </div>
          <ShoppingBag className="w-56 h-56 text-white/10 absolute -right-8 -bottom-8 rotate-12 group-hover:scale-125 transition-transform duration-700 pointer-events-none" />
        </div>
      </div>

      {/* Featured Grid */}
      <div className="px-8 space-y-10">
        <div className="flex justify-between items-end">
          <div>
            <div className="flex items-center gap-2 mb-2 text-primary">
               <TrendingUp className="w-5 h-5" />
               <span className="text-[10px] font-black uppercase tracking-[0.3em] italic">Hot & Fresh</span>
            </div>
            <h2 className="text-5xl font-black italic tracking-tighter leading-none">THE STASH 🔥</h2>
          </div>
          <Button variant="link" className="text-primary font-black italic text-lg hover:underline decoration-4">SEE ALL</Button>
        </div>

        {loading ? (
           <div className="grid grid-cols-2 gap-8">
              {[1,2,3,4].map(i => (
                <div key={i} className="aspect-square bg-white/5 rounded-[3rem] animate-pulse border-4 border-white/5" />
              ))}
           </div>
        ) : (
          <div className="grid grid-cols-2 gap-8">
            {items.map((item: any) => (
              <Link href={`/customer/product/${item.id}`} key={item.id} className="block group">
                <Card className="cartoon-card overflow-hidden cursor-pointer border-none bg-card relative shadow-[20px_20px_0px_0px_rgba(0,0,0,0.2)] hover:shadow-[25px_25px_0px_0px_rgba(122,99,255,0.2)] active:translate-y-2 transition-all">
                  <div className="relative aspect-[4/5] overflow-hidden">
                    <img 
                      src={item.imageUrl || `https://picsum.photos/seed/${item.id}/400/500`} 
                      alt={item.name} 
                      className="w-full h-full object-cover transition-transform group-hover:scale-110 duration-700" 
                      data-ai-hint="product image"
                    />
                    <div className="absolute top-4 left-4 z-10">
                      <Badge className="bg-primary/90 backdrop-blur-xl border-2 border-white/20 font-black italic text-[10px] px-4 py-1 rounded-full shadow-2xl">
                        {item.category || 'Hero'}
                      </Badge>
                    </div>
                    <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
                  </div>
                  <CardContent className="p-6 relative bg-card">
                    <h4 className="font-black text-xl truncate italic text-white mb-2 leading-tight">{item.name}</h4>
                    <div className="flex items-center gap-2 mb-4">
                      <div className="flex items-center text-accent">
                        <Star className="w-4 h-4 fill-current" />
                        <span className="text-xs font-black ml-1">4.9</span>
                      </div>
                      <span className="text-[8px] font-black opacity-30 uppercase tracking-widest italic">Best Seller</span>
                    </div>
                    <div className="flex justify-between items-center mt-2">
                      <div className="flex flex-col">
                         <span className="text-[10px] font-black opacity-30 uppercase italic leading-none">Price</span>
                         <p className="font-black text-3xl text-primary tracking-tighter italic">₹{item.basePrice}</p>
                      </div>
                      <div className="h-14 w-14 bg-primary rounded-2xl flex items-center justify-center border-b-8 border-primary-foreground/20 group-active:translate-y-2 group-active:border-b-0 transition-all shadow-xl">
                        <ShoppingBag className="w-7 h-7 text-white" />
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </Link>
            ))}
          </div>
        )}
      </div>

      <BottomNav role="CUSTOMER" />
    </div>
  );
}
