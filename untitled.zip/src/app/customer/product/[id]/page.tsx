
"use client"

import React, { useState, useMemo } from 'react';
import { useParams, useRouter } from 'next/navigation';
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { 
  ArrowLeft, 
  ShoppingBag, 
  Star, 
  Plus,
  Minus,
  Loader2,
  MapPin,
  Phone,
  Mail,
  CreditCard,
  Banknote,
  QrCode
} from 'lucide-react';
import { useDoc, useFirestore, useUser } from '@/firebase';
import { doc, addDoc, collection, serverTimestamp } from 'firebase/firestore';
import { useToast } from '@/hooks/use-toast';
import { Badge } from '@/components/ui/badge';
import { BottomNav } from '@/components/layout/bottom-nav';
import { cn } from '@/lib/utils';
import { PLATFORM_FEE, DELIVERY_FEE, UPI_ID_ADMIN } from '@/lib/types';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { UPIQRCode } from '@/components/ui/up-qr-code';
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";

export default function ProductDetailPage() {
  const { id } = useParams();
  const router = useRouter();
  const db = useFirestore();
  const { user } = useUser();
  const { toast } = useToast();
  
  const [quantity, setQuantity] = useState(1);
  const [selectedSize, setSelectedSize] = useState<string | null>(null);
  const [isOrdering, setIsOrdering] = useState(false);
  const [showCheckout, setShowCheckout] = useState(false);
  const [paymentMethod, setPaymentMethod] = useState<'COD' | 'ONLINE'>('COD');
  const [transactionId, setTransactionId] = useState('');

  // Form states
  const [address, setAddress] = useState('');
  const [phone, setPhone] = useState('');
  const [email, setEmail] = useState('');

  const productRef = useMemo(() => {
    if (!db || !id) return null;
    return doc(db, 'products', id as string);
  }, [db, id]);

  const { data: product, loading } = useDoc(productRef);

  const basePrice = Number(product?.basePrice) || 0;
  const totalAmount = (basePrice * quantity) + PLATFORM_FEE + DELIVERY_FEE;

  const handleOpenCheckout = () => {
    if (!user) {
      toast({ variant: "destructive", title: "Wait Up! 🛑", description: "You need to login first to order treasures." });
      router.push('/login');
      return;
    }
    if (product?.sizes && product.sizes.length > 0 && !selectedSize) {
      toast({ variant: "destructive", title: "Size Missing! 📏", description: "Please select a size to continue." });
      return;
    }
    setEmail(user.email || '');
    setShowCheckout(true);
  };

  const handleOrder = async () => {
    if (!address || !phone || !email) {
      toast({ variant: "destructive", title: "Details Missing!", description: "Please provide all details." });
      return;
    }

    if (paymentMethod === 'ONLINE' && transactionId.length < 6) {
      toast({ variant: "destructive", title: "Transaction ID Missing!", description: "Please enter the UTR/Ref ID." });
      return;
    }

    if (!product || !db || !user) return;

    setIsOrdering(true);
    try {
      const orderData = {
        customerId: user.uid,
        customerName: user.displayName || 'Legendary User',
        customerPhone: phone,
        customerEmail: email,
        shopId: product.shopId,
        items: [{
          productId: id,
          name: product.name,
          quantity: quantity,
          basePrice: basePrice,
          selectedSize: selectedSize
        }],
        totalAmount: totalAmount,
        status: 'PENDING_SHOP_APPROVAL',
        paymentMethod: paymentMethod,
        paymentStatus: paymentMethod === 'ONLINE' ? 'VERIFYING' : 'PENDING',
        transactionId: transactionId || null,
        deliveryAddress: address,
        qrData: `order_${Date.now()}_${user.uid}`,
        createdAt: serverTimestamp()
      };

      await addDoc(collection(db, 'orders'), orderData);

      toast({ 
        title: paymentMethod === 'ONLINE' ? "PAYMENT SUBMITTED! ⚡" : "ORDER PLACED! 🚀", 
        description: paymentMethod === 'ONLINE' ? "Admin will verify your payment ID soon." : "Waiting for shop approval."
      });
      router.push('/customer/orders');
    } catch (error: any) {
      console.error(error);
      toast({ variant: "destructive", title: "Order Failed ❌", description: error.message });
    } finally {
      setIsOrdering(false);
    }
  };

  if (loading) return <div className="min-h-screen flex items-center justify-center bg-background"><Loader2 className="animate-spin w-20 h-20 text-primary" /></div>;

  return (
    <div className="min-h-screen bg-background pb-44 font-body">
      <div className="relative h-[40vh]">
        <img src={product?.imageUrl} className="w-full h-full object-cover" alt={product?.name} />
        <Button variant="ghost" size="icon" onClick={() => router.back()} className="absolute top-8 left-6 glass rounded-2xl border-4 border-white/20">
          <ArrowLeft className="w-8 h-8 text-white" />
        </Button>
      </div>

      <div className="px-8 -mt-8 relative z-10 bg-card rounded-t-[3.5rem] pt-10 border-t-8 border-white/5">
        <h1 className="text-4xl font-black italic mb-6 text-white uppercase">{product?.name}</h1>
        <div className="flex justify-between items-center mb-10">
          <Badge className="bg-primary px-6 py-2 rounded-2xl font-black italic uppercase">{product?.category}</Badge>
          <span className="text-primary font-black text-5xl italic tracking-tighter">₹{basePrice}</span>
        </div>

        <div className="space-y-10">
           <div className="bg-white/5 p-8 rounded-[3rem] border-4 border-white/10 flex items-center justify-between">
            <span className="text-xl font-black italic uppercase opacity-40">Quantity</span>
            <div className="flex items-center gap-6">
              <Button size="icon" className="w-14 h-14 rounded-2xl border-4" onClick={() => setQuantity(Math.max(1, quantity - 1))}><Minus /></Button>
              <span className="text-4xl font-black italic">{quantity}</span>
              <Button size="icon" className="w-14 h-14 rounded-2xl border-4" onClick={() => setQuantity(quantity + 1)}><Plus /></Button>
            </div>
          </div>

          {product?.sizes?.length > 0 && (
            <div className="space-y-4">
              <Label className="text-xl font-black italic uppercase">Size</Label>
              <div className="grid grid-cols-3 gap-4">
                {product.sizes.map((s: string) => (
                  <Button 
                    key={s} 
                    variant={selectedSize === s ? "default" : "outline"} 
                    className="h-16 rounded-2xl font-black italic text-xl border-4"
                    onClick={() => setSelectedSize(s)}
                  >
                    {s}
                  </Button>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>

      <div className="fixed bottom-0 left-0 right-0 p-6 bg-background/90 backdrop-blur-3xl border-t-8 border-white/5">
         <div className="flex items-center justify-between gap-6 max-w-4xl mx-auto">
            <div className="flex flex-col">
              <span className="text-[10px] font-black uppercase tracking-widest opacity-40 italic">Total Cost</span>
              <span className="text-4xl font-black italic text-primary">₹{totalAmount}</span>
            </div>
            <Button className="flex-1 h-20 rounded-[2.5rem] text-3xl font-black italic bg-primary shadow-2xl border-b-8 active:translate-y-2 transition-all" onClick={handleOpenCheckout}>
              GET IT! 🚀
            </Button>
         </div>
      </div>

      <Dialog open={showCheckout} onOpenChange={setShowCheckout}>
        <DialogContent className="glass border-primary rounded-[3rem] p-0 overflow-hidden sm:max-w-lg">
          <div className="p-8 bg-primary/10 border-b-4 border-white/5 text-center">
            <DialogTitle className="text-3xl font-black italic uppercase tracking-tighter">DEPLOY MISSION 🗺️</DialogTitle>
          </div>
          <div className="p-8 space-y-6 max-h-[70vh] overflow-y-auto no-scrollbar">
            <div className="space-y-4">
              <div className="space-y-2">
                <Label className="font-black italic text-[10px] uppercase tracking-widest opacity-40">Drop Zone (Address)</Label>
                <Input className="h-14 bg-white/5 border-4 rounded-2xl font-bold" placeholder="Full Address" value={address} onChange={(e) => setAddress(e.target.value)} />
              </div>
              <div className="space-y-2">
                <Label className="font-black italic text-[10px] uppercase tracking-widest opacity-40">Frequency (Phone)</Label>
                <Input className="h-14 bg-white/5 border-4 rounded-2xl font-bold" placeholder="Mobile Number" value={phone} onChange={(e) => setPhone(e.target.value)} />
              </div>
            </div>

            <div className="space-y-4">
              <Label className="text-xl font-black italic uppercase">Payment Gear</Label>
              <Tabs defaultValue="COD" onValueChange={(v) => setPaymentMethod(v as any)}>
                <TabsList className="grid grid-cols-2 h-16 bg-white/5 rounded-2xl p-2">
                  <TabsTrigger value="COD" className="rounded-xl font-black italic"><Banknote className="mr-2" /> COD</TabsTrigger>
                  <TabsTrigger value="ONLINE" className="rounded-xl font-black italic"><CreditCard className="mr-2" /> ONLINE</TabsTrigger>
                </TabsList>
                <TabsContent value="ONLINE" className="pt-6 space-y-6 flex flex-col items-center">
                   <UPIQRCode upiId={UPI_ID_ADMIN} amount={totalAmount} transactionNote="Zingo Order" />
                   <div className="w-full space-y-2">
                      <Label className="font-black italic text-[10px] uppercase tracking-widest opacity-40 text-center block">Enter Transaction ID (UTR)</Label>
                      <Input className="h-16 bg-white/10 border-4 border-primary rounded-2xl text-center text-2xl font-mono tracking-widest" maxLength={12} placeholder="12-digit ID" value={transactionId} onChange={(e) => setTransactionId(e.target.value)} />
                   </div>
                </TabsContent>
              </Tabs>
            </div>

            <Button className="w-full h-20 text-2xl font-black italic rounded-[2rem] bg-primary border-b-8 active:translate-y-2 transition-all shadow-2xl" onClick={handleOrder} disabled={isOrdering}>
              {isOrdering ? <Loader2 className="animate-spin" /> : "START MISSION! 🚀"}
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      <BottomNav role="CUSTOMER" />
    </div>
  );
}
