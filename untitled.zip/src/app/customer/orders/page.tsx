
"use client"

import React from 'react';
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { ShoppingBag, Package, MapPin, Clock, Loader2, ArrowRight } from 'lucide-react';
import { BottomNav } from '@/components/layout/bottom-nav';
import { useCollection, useUser, useFirestore } from '@/firebase';
import { collection, query, where } from 'firebase/firestore';
import Link from 'next/link';

export default function CustomerOrders() {
  const { user } = useUser();
  const db = useFirestore();

  const ordersQuery = React.useMemo(() => {
    if (!db || !user?.uid) return null;
    return query(
      collection(db, 'orders'), 
      where('customerId', '==', user.uid)
    );
  }, [db, user?.uid]);

  const { data: rawOrders, loading } = useCollection(ordersQuery);

  const sortedOrders = React.useMemo(() => {
    if (!rawOrders) return [];
    return [...rawOrders].sort((a: any, b: any) => 
      (b.createdAt?.seconds || 0) - (a.createdAt?.seconds || 0)
    );
  }, [rawOrders]);

  return (
    <div className="min-h-screen bg-background pb-32 font-body">
      <header className="p-10 gradient-bg rounded-b-[4rem] text-white shadow-2xl relative overflow-hidden">
        <h1 className="text-5xl font-black italic tracking-tighter uppercase leading-none">THE STASH</h1>
        <p className="text-indigo-100/60 font-black italic mt-2 uppercase text-xs tracking-widest">Tracking your Zingo treasures</p>
        <ShoppingBag className="absolute -right-10 -bottom-10 w-48 h-48 text-white/10 rotate-12" />
      </header>

      <div className="p-6 space-y-6">
        {loading ? (
          <div className="flex flex-col items-center justify-center py-24 gap-6">
            <div className="w-20 h-20 border-8 border-primary border-t-transparent rounded-full animate-spin" />
            <p className="font-black italic text-2xl text-primary animate-pulse uppercase tracking-tighter">RAIDING THE DATABASE...</p>
          </div>
        ) : sortedOrders.length === 0 ? (
          <div className="text-center py-24 opacity-40 flex flex-col items-center gap-6">
            <div className="w-32 h-32 bg-white/5 rounded-[3rem] flex items-center justify-center">
              <ShoppingBag className="w-16 h-16" />
            </div>
            <div>
              <p className="text-3xl font-black italic uppercase tracking-tighter">THE BAG IS EMPTY!</p>
              <p className="text-sm font-bold mt-2 italic">Don't let the deals escape. Start a mission!</p>
            </div>
            <Link href="/customer/home">
              <Button className="h-16 rounded-2xl px-10 font-black italic text-xl border-b-8 border-primary-foreground/20 active:translate-y-1">
                BACK TO SHOP 🚀
              </Button>
            </Link>
          </div>
        ) : (
          <div className="grid gap-6">
            {sortedOrders.map((order: any) => (
              <Card key={order.id} className="cartoon-card overflow-hidden group hover:scale-[1.02] transition-all bg-card/40 relative border-none">
                <CardContent className="p-8">
                  <div className="flex justify-between items-start mb-8">
                    <div>
                      <p className="text-[10px] text-primary font-black uppercase tracking-[0.3em] opacity-60 mb-2">MISSION: #ZNG-{order.id.slice(-6).toUpperCase()}</p>
                      <h4 className="text-5xl font-black italic text-white tracking-tighter leading-none">₹{order.totalAmount}</h4>
                    </div>
                    <Badge className={cn(
                      "border-4 px-5 py-2 rounded-2xl font-black italic text-xs uppercase shadow-lg",
                      order.status === 'DELIVERED' ? "bg-green-500 border-green-200" : "bg-primary border-white/20"
                    )}>
                      {order.status?.replace(/_/g, ' ')}
                    </Badge>
                  </div>

                  <div className="space-y-4 pt-6 border-t-4 border-white/5">
                    <div className="flex items-center gap-4 text-lg font-bold italic text-indigo-100/60">
                      <div className="w-12 h-12 rounded-2xl bg-primary/10 flex items-center justify-center border-2 border-primary/10">
                        <Package className="w-6 h-6 text-primary" />
                      </div>
                      <span>{order.items?.length || 0} Hero Items Packed</span>
                    </div>
                    <div className="flex items-center gap-4 text-lg font-bold italic text-indigo-100/60">
                      <div className="w-12 h-12 rounded-2xl bg-accent/10 flex items-center justify-center border-2 border-accent/10">
                        <MapPin className="w-6 h-6 text-accent" />
                      </div>
                      <span className="truncate max-w-[200px]">{order.deliveryAddress || 'The Secret Hideout'}</span>
                    </div>
                  </div>
                  
                  <Button variant="ghost" className="w-full h-14 mt-8 rounded-2xl bg-white/5 font-black italic border-2 border-white/5 hover:bg-primary/20 hover:text-white group">
                    VIEW MISSION DETAILS <ArrowRight className="ml-2 w-5 h-5 group-hover:translate-x-2 transition-transform" />
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>

      <BottomNav role="CUSTOMER" />
    </div>
  );
}

function cn(...classes: (string | boolean | undefined)[]) {
  return classes.filter(Boolean).join(' ');
}
